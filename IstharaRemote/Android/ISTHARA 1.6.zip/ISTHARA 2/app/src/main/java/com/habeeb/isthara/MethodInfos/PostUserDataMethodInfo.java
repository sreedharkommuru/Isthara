package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 19/09/17.
 */

public class PostUserDataMethodInfo extends MethodInfo
{

    public PostUserDataMethodInfo()
    {
        params.put("userid", ApplicationClass.userLeaseID);
        params.put("PhoneNumber",ApplicationClass.userMobileNumber);
        params.put("RoomNumber",ApplicationClass.userRoomNumber);
        params.put("BedNumber",ApplicationClass.userBedNumber);
        params.put("UserName",ApplicationClass.userLoginName);
        params.put("UserLoginDate",ApplicationClass.getCurrentDateandTime());
        params.put("DeviceToken",ApplicationClass.deviceToken);

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.usersListPostService;
    }
}
