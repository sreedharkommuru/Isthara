package com.habeeb.isthara;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

/**
 * Created by habeeb on 30/09/17.
 */

public class MyNotificationManager
{
    private Context contextM;
    public static final int NOTIFICATION_ID = 234;

    public MyNotificationManager(Context context)
    {
        this.contextM = context;
    }

    public void showNotification(String from, String notification, Intent intent)
    {
        PendingIntent pendingIntent = PendingIntent.getActivity(

                contextM,
                NOTIFICATION_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(contextM);

        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        Notification mnotification = builder.setSmallIcon(R.mipmap.ic_launcher)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setContentTitle(from)
                .setContentText(notification)
                .setSound(defaultSoundUri)
                .setLargeIcon(BitmapFactory.decodeResource(contextM.getResources(),R.mipmap.ic_launcher))
                .build();

        mnotification.flags |= Notification.FLAG_AUTO_CANCEL;

        NotificationManager notificationManager = (NotificationManager) contextM.getSystemService(contextM.NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICATION_ID, mnotification);
    }

}
