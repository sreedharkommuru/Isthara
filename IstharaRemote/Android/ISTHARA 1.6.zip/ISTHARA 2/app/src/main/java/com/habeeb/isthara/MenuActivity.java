package com.habeeb.isthara;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.MethodInfos.PostUserDataMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 26/08/17.
 */

public class MenuActivity  extends Activity implements MethodExecutor.TaskDelegate
{

    int serviceCount = 0;

    /*
   * LIST VIEW OBJECTS
   * */
    ListAdapter adapter;
    ListView listView;


    ArrayList menuArrayList = new ArrayList();
    ArrayList menuFontArrayList = new ArrayList();

    ArrayList colorCodesList = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Home");




        if (ApplicationClass.userLoginRole.equals("admin"))
        {
            menuArrayList.add("Maintenances List");
            menuArrayList.add("Feedbacks List");
            menuArrayList.add("Sales Referral List");
            menuArrayList.add("Manage Events");
            menuArrayList.add("Food Menu");
            menuArrayList.add("Users List");
            menuArrayList.add("Locations List");


            menuFontArrayList.add("&#xf085;");//xf0c0
            menuFontArrayList.add("&#xf0e6;");
            menuFontArrayList.add("&#xf0c1;");
            menuFontArrayList.add("&#xf073;");
            menuFontArrayList.add("&#xf0f5;");
            menuFontArrayList.add("&#xf0c0;");
            menuFontArrayList.add("&#xf08d;");

            colorCodesList.add("#FF4081");
            colorCodesList.add("#00BFFF");
            colorCodesList.add("#3CB371");
            colorCodesList.add("#963e48");
            colorCodesList.add("#000000");
            colorCodesList.add("#b97d56");
            colorCodesList.add("#FF4081");
            colorCodesList.add("#FF4081");

        }
        else
        {
            menuArrayList.add("Maintenance request");
            menuArrayList.add("Feedback");
            menuArrayList.add("Sales Referral - Invite and earn");
            menuArrayList.add("Event information");
            //menuArrayList.add("Locations available in Isthara ");
            menuArrayList.add("Contact us");
            menuArrayList.add("Food menu for the week");
            //menuArrayList.add("Other Locations");
            menuArrayList.add("Chat To Admin");

            menuFontArrayList.add("&#xf085;");
            menuFontArrayList.add("&#xf044;");
            menuFontArrayList.add("&#xf201;");
            menuFontArrayList.add("&#xf073;");
            menuFontArrayList.add("&#xf095;");
            menuFontArrayList.add("&#xf0f5;");
            //menuFontArrayList.add("&#xf08d;");
            menuFontArrayList.add("&#xf0c0;");

            colorCodesList.add("#FF4081");
            colorCodesList.add("#00BFFF");
            colorCodesList.add("#3CB371");
            colorCodesList.add("#963e48");
            colorCodesList.add("#000000");
            colorCodesList.add("#b97d56");
            colorCodesList.add("#FF4081");

            postUsersData();
        }


        listView = (ListView)findViewById(R.id.listView);

        adapter= new ListAdapter(menuArrayList,menuFontArrayList,menuArrayList,0);
        adapter.colorCodes = colorCodesList;
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

                if (ApplicationClass.userLoginRole.equals("admin"))
                {
                    if (position == 0)
                    {
                        usersListAction();
                    }
                    else if (position == 1)
                    {
                        feedbackUsersAction();
                    }
                    else if (position == 2)
                    {
                        salesReferralListAction();
                    }
                    else if (position == 3)
                    {
                        manageEventsAction();
                    }
                    else if (position == 4)
                    {
                        foodMenuListAction();
                    }
                    else if (position == 5)
                    {
                        usersListActivityAction();
                    }
                    else if (position == 6)
                    {
                        istharaLocationsAction();
                    }
                }
                else
                {
                    if (position == 0)
                    {
                        maintenanceRequestAction();
                    }
                    else if (position == 1)
                    {
                        feedBackAction();
                    }
                    else if (position == 2)
                    {
                        salesReferralsAction();
                    }
                    else if (position == 3)
                    {
                        eventsDisplayAction();
                    }
                    else if (position == 4)
                    {
                        contactUsAction();
                    }
                    else if (position == 5)
                    {
                        foodMenuAction();
                    }
                    else if (position == 6)
                    {
                        usersAdminChatActivityAction();

                    }
                }




            }
        });


    }



    /*
    * MANAGE EVENTS ACTIVITY INTENT ACTION
    * */
    private void maintenanceRequestAction()
    {


        Intent intent = new Intent(this,UsersMaintenanceActivity.class);
        startActivity(intent);


    }

    /*
    * FEEDBACK INTENT ACTION
    * */
    private void feedBackAction()
    {
        Intent intent = new Intent(this,FeedBackActivity.class);
        startActivity(intent);

    }

    /*
    * SALES REFERRALS ACTIVITY INTENT ACTION
    * */
    private void salesReferralsAction()
    {
        Intent intent = new Intent(this,UserSalesReferralActivity.class);
        startActivity(intent);
    }



    /*
    * EVENTS DISPLAY ACTIVITY INTENT ACTION
    * */
    private void eventsDisplayAction()
    {
        Intent intent = new Intent(this,EventDisplayActivity.class);
        startActivity(intent);
    }

    /*
    * CONTACT ACTIVITY INTENT ACTION
    * */
    private void contactUsAction()
    {
        Intent intent = new Intent(this,ContactsActivity.class);
        startActivity(intent);
    }

    /*
    * FOOD MENU ACTIVITY INTENT ACTION
    * */
    private void foodMenuAction()
    {
        Intent intent = new Intent(this,UserFoodMenuActivity.class);
        startActivity(intent);
    }

    /*
    * USERS TO ADMIN ACTIVITY INTENT
    * */
    private void usersAdminChatActivityAction()
    {
        Intent intent = new Intent(this,UserToAdminChatActivity.class);
        startActivity(intent);
    }

    /*
    * USERS LIST ACTIVITY INTENT
    * */
    private void usersListActivityAction()
    {
        Intent intent = new Intent(this,UsersListActivity.class);
        startActivity(intent);
    }
    /*
    * ISTHARA LOCATIONS ACTIVITY INTENT ACTION
    * */
    private void istharaLocationsAction()
    {
        Intent intent = new Intent(this,IstharaLocationsActivity.class);
        startActivity(intent);
    }

    /*
    * MAINTENANCE LIST INTENT ACTION
    * */
    private void usersListAction()
    {

        Intent intent = new Intent(this,MaintenanceUsersListActivity.class);
        startActivity(intent);
    }

    /*
    * MANAGE EVENTS ACTIVITY INTENT ACTION
    * */
    private void manageEventsAction()
    {
        Intent intent = new Intent(this,ManageEventsActivity.class);
        startActivity(intent);
    }

    /*
    * FEEDBACK USERS ACTIVITY INTENT ACTION
    * */
    private void feedbackUsersAction()
    {
        Intent intent = new Intent(this,FeedbackListActivity.class);
        startActivity(intent);
    }

    /*
    * SALES REFERRALS ACTIVITY INTENT ACTION
    * */
    private void salesReferralListAction()
    {
        Intent intent = new Intent(this,SalesReferralsListActivity.class);
        startActivity(intent);
    }


    /*
    * SALES REFERRALS ACTIVITY INTENT ACTION
    * */
    private void foodMenuListAction()
    {
        Intent intent = new Intent(this,ManageFoodMenuActivity.class);
        startActivity(intent);
    }



    /*
   * POST USERS DATA METHOD INFO
   * */
    private void postUsersData()
    {
        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        PostUserDataMethodInfo postUserDataMethodInfo = new PostUserDataMethodInfo();
        methodExecutor.execute(postUserDataMethodInfo);

    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {

        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }
}