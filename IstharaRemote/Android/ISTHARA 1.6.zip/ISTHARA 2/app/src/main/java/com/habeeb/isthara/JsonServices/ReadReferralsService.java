package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 15/09/17.
 */

public class ReadReferralsService
{
    public ArrayList namesListArray = new ArrayList();
    public ArrayList contactsListArray = new ArrayList();
    public ArrayList usersListArray = new ArrayList();
    public ArrayList locationListArray = new ArrayList();

    public void getReferralsData(String jsonData)
    {
        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String username = jsonObject.getString("username");
                        String refname = jsonObject.getString("refname");
                        String refnumber = jsonObject.getString("refnumber");
                        String bednumber = jsonObject.getString("bednumber");

                        username = username.trim();
                        refname = refname.trim();
                        refnumber = refnumber.trim();

                        if (refname.length() != 0 && !refname.contains("null"))
                        {
                            namesListArray.add(refname);
                            contactsListArray.add(refnumber);
                            usersListArray.add(username+"("+bednumber+")");
                            locationListArray.add(jsonObject.getString("location"));

                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }
}
