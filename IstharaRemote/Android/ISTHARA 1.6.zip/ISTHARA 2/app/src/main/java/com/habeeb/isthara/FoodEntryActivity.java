package com.habeeb.isthara;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadFoodMenuService;
import com.habeeb.isthara.MethodInfos.FoodMenuEntryMethodInfo;
import com.habeeb.isthara.MethodInfos.FoodMenuGetMethodInfo;

/**
 * Created by habeeb on 17/09/17.
 */

public class FoodEntryActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    EditText breakFastEditText, dinnerEditText;
    String breakFastString = "";
    String dinnerString = "";
    String dateIsString = "";

    String entryString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_entry_layout);

        TextView topTitleTextView = (TextView) findViewById(R.id.topTitleTextView);


        dateIsString = getIntent().getStringExtra("date");
        entryString = getIntent().getStringExtra("entry");

        topTitleTextView.setText(dateIsString);

        breakFastEditText = (EditText)findViewById(R.id.breakFastEditText);
        dinnerEditText = (EditText)findViewById(R.id.dinnerEditText);

        if (entryString.equals("user"))
        {
            breakFastEditText.setEnabled(false);
            dinnerEditText.setEnabled(false);

            findViewById(R.id.foodPostButton).setVisibility(View.GONE);

            getDataMethodInfo();
        }
        else
        {
            getDataMethodInfo();
        }


    }

    /*
    * POST FOOD MENU BUTTON ACTION
    * */
    public void postmenuButtonAction(View view)
    {
        breakFastString = breakFastEditText.getText().toString().trim();
        dinnerString = dinnerEditText.getText().toString().trim();

        if (breakFastString.length() == 0 && dinnerString.length() == 0)
        {
            toastClass.ToastCalled(this,"Required Food Menu");
            return;
        }
        else
        {
            postDataMethodInfo();
        }

    }


    /*
    * POST DATA METHOD INFO
    * */
    private void postDataMethodInfo()
    {

        serviceCount = 0;
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        FoodMenuEntryMethodInfo foodMenuEntryMethodInfo = new FoodMenuEntryMethodInfo(breakFastString,dinnerString,dateIsString);
        methodExecutor.execute(foodMenuEntryMethodInfo);
    }

    /*
    * GET DATA METHOD INFO
    * */
    private void getDataMethodInfo()
    {

        serviceCount = 1;
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        FoodMenuGetMethodInfo foodMenuGetMethodInfo = new FoodMenuGetMethodInfo(dateIsString,0);
        methodExecutor.execute(foodMenuGetMethodInfo);
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            toastClass.ToastCalled(this,result);
            finish();
        }
        else if (serviceCount == 1)
        {
            readResponseData(result);
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }


    /*
    * READ RESPONSE DATA
    * */
    private void readResponseData(String response)
    {
        ReadFoodMenuService readFoodMenuService = new ReadFoodMenuService();
        readFoodMenuService.getMenuData(response);

        breakFastEditText.setText("BreakFast :- "+readFoodMenuService.breakFastString);
        dinnerEditText.setText("Dinner :- "+readFoodMenuService.dinnerString);


        if (entryString.equals("user"))
        {
            if (readFoodMenuService.breakFastString.length() == 0)
            {
                breakFastEditText.setText("No Break Fast");
            }

            if (readFoodMenuService.dinnerString.length() == 0)
            {
                dinnerEditText.setText("No Dinner");
            }
        }
        else
        {

            if (readFoodMenuService.breakFastString.length() == 0)
            {
                breakFastEditText.setText("");
            }

            if (readFoodMenuService.dinnerString.length() == 0)
            {
                dinnerEditText.setText("");
            }
        }



    }
}