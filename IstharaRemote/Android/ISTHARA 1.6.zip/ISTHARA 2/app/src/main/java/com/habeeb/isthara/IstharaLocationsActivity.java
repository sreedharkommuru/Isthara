package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadLocationsService;
import com.habeeb.isthara.MethodInfos.GetLocationsMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 25/09/17.
 */

public class IstharaLocationsActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ArrayList locationNameArray = new ArrayList();
    ArrayList locationIDArray = new ArrayList();

    AdminListAdapter adapter;
    ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.locations_layout);


        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Isthara Locations");



    }

    @Override
    protected void onResume() {
        super.onResume();

        getLocationsService();
    }

    /*
        * GET LOCATIONS DATA SERIVCE
        * */
    private void getLocationsService()
    {

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        GetLocationsMethodInfo getLocationsMethodInfo = new GetLocationsMethodInfo();
        methodExecutor.execute(getLocationsMethodInfo);


    }


    @Override
    public void onTaskFisnishGettingData(String result)
    {
        readLocationService(result);
    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }


    /*
    * READ LOCATIONS SERVICE
    * */
    private void readLocationService(String response)
    {

        locationIDArray.clear();
        locationNameArray.clear();

        if (listView != null)
        {
            listView.setAdapter(null);
        }

        ReadLocationsService readLocationsService = new ReadLocationsService();
        readLocationsService.getLocationsData(response);

        locationNameArray.addAll(readLocationsService.locationsListArray);
        locationIDArray.addAll(readLocationsService.locationsIDsListArray);


        if (locationNameArray.size() > 0)
        {
            loadLocationsList();
        }
    }


    /*
    * LOAD LOCATIONS IN LIST
    * */
    private void loadLocationsList()
    {


        listView = (ListView)findViewById(R.id.listView);

        adapter= new AdminListAdapter(locationNameArray);


        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                locationActivity(position);

            }
        });


    }

    /*
    * NEW LOCATION BUTTON
    * */
    public void addButtonAction(View view)
    {
        Intent intent = new Intent(this,LocationsViewActivity.class);
        intent.putExtra("NewRecord","NewRecord");
        startActivity(intent);
    }

    /*
    * LOCATION NAME
    * */
    private void locationActivity(int position)
    {
        Intent intent = new Intent(this,LocationsViewActivity.class);
        intent.putExtra("locationName",locationNameArray.get(position).toString());
        intent.putExtra("locationID",locationIDArray.get(position).toString());
        startActivity(intent);
    }

}
