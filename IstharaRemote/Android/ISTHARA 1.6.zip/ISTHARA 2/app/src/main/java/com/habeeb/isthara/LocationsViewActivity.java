package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.habeeb.isthara.MethodInfos.LocationDeleteMethodInfo;
import com.habeeb.isthara.MethodInfos.LocationInsertMethodInfo;
import com.habeeb.isthara.MethodInfos.LocationUpdateMethodInfo;

/**
 * Created by habeeb on 07/01/18.
 */

public class LocationsViewActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int editCheck = 0;

    EditText locationEditText;

    String locationName = "";
    String locationID = "";

    int buttonCount = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_view_layout);


        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Locations");


        locationEditText = (EditText)findViewById(R.id.locationEditText);

        if (getIntent().hasExtra("NewRecord"))
        {
            findViewById(R.id.updateLocations).setVisibility(View.GONE);
            findViewById(R.id.submitButton).setVisibility(View.VISIBLE);
        }
        else
        {
            locationName = getIntent().getStringExtra("locationName");
            locationID = getIntent().getStringExtra("locationID");

            locationEditText.setText(locationName);
            locationEditText.setEnabled(false);
        }


    }


    /*
    * EDIT BUTTON ACTION
    * */
    public void editButtonAction(View view)
    {

        Button button = (Button)view;

        if (editCheck == 0)
        {
            editCheck = 1;
            button.setText("SUBMIT");
            locationEditText.setEnabled(true);
        }
        else
        {
           locationName = locationEditText.getText().toString().trim();
           if (locationName.length() == 0)
           {
               toastClass.ToastCalled(this,"Required Message");
               return;
           }

            buttonCount = 0;
           showAlertMessage("Alert","Are you sure want to update?");


        }
    }

    /*
    * DELETE BUTTON ACTION
    * */
    public void deleteButtonAction(View view)
    {
        buttonCount = 1;
        showAlertMessage("Alert","Are you sure want to Delete?");

    }

    /*
    * SUBMIT BUTTON ACTION
    * */
    public void submitButtonAction(View view)
    {
        locationName = locationEditText.getText().toString().trim();
        if (locationName.length() == 0)
        {
            toastClass.ToastCalled(this,"Required Message");
            return;
        }

        buttonCount = 2;
        showAlertMessage("Alert","Are you sure want to Add?");

    }


    /*
    * NEW LOCATION INSERT
    * */
    private void insertLocation()
    {
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        LocationInsertMethodInfo locationInsertMethodInfo = new LocationInsertMethodInfo(locationName,ApplicationClass.userRoomNumber);
        methodExecutor.execute(locationInsertMethodInfo);
    }

    /*
    * UPDATE LOCATION INSERT
    * */
    private void updateLocation()
    {
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        LocationUpdateMethodInfo locationUpdateMethodInfo = new LocationUpdateMethodInfo(locationName,ApplicationClass.userRoomNumber,locationID);
        methodExecutor.execute(locationUpdateMethodInfo);
    }


    /*
    * DELETE LOCATION INSERT
    * */
    private void deleteLocation()
    {
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        LocationDeleteMethodInfo locationDeleteMethodInfo = new LocationDeleteMethodInfo(ApplicationClass.userRoomNumber,locationID);
        methodExecutor.execute(locationDeleteMethodInfo);
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        toastClass.ToastCalled(this,result);
        finish();
    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }

    private void showAlertMessage(String title,String message)
    {
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(this);

        alertDialog2.setTitle(title);
        alertDialog2.setMessage(message);


        alertDialog2.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        buttonCountAction();
                    }
                });


        alertDialog2.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.cancel();
                    }
                });


        alertDialog2.show();
    }


    /*
    * BUTTON COUNT ACTION
    * */
    private void buttonCountAction()
    {
        if (buttonCount == 0)
        {
            updateLocation();
        }
        else if (buttonCount == 1)
        {
            deleteLocation();
        }
        else if (buttonCount == 2)
        {
            insertLocation();
        }
    }

}
