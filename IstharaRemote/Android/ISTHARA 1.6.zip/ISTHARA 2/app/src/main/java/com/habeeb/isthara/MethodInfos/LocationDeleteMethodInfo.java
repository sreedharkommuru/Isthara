package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 07/01/18.
 */

public class LocationDeleteMethodInfo extends MethodInfo
{

    public LocationDeleteMethodInfo(String userid,String locationID)
    {
        params.put("locationID",locationID);
        params.put("userid",userid);
        params.put("delete","delete");

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.locationsPostService;
    }
}
