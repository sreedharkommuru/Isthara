package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 14/09/17.
 */

public class EventPostMethodInfo extends MethodInfo
{

    public EventPostMethodInfo(String userID,String messageString,String eventDateString)
    {
        String date = ApplicationClass.getCurrentDateandTime();

        params.put("userid",ApplicationClass.userLeaseID);
        params.put("message",messageString);
        params.put("eventdate",eventDateString);
        params.put("insdate",date);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.eventPostService;
    }
}
