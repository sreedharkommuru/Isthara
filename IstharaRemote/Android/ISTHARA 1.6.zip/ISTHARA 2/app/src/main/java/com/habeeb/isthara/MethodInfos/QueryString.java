package com.habeeb.isthara.MethodInfos;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by habeeb on 18/04/16.
 */
public class QueryString {

    private String query = "";



    public QueryString(HashMap<String, Object> map) throws UnsupportedEncodingException
    {
        Iterator it = map.entrySet().iterator();
        while (it.hasNext())
        {
            Map.Entry pairs = (Map.Entry)it.next();
            query += URLEncoder.encode((String) pairs.getValue(), "utf-8");
            if (it.hasNext()) { query += "/"; }
        }
    }



/*
    public QueryString(HashMap<String, Object> map) throws UnsupportedEncodingException
    {
        Iterator it = map.entrySet().iterator();
        while (it.hasNext())
        {
            Map.Entry pairs = (Map.Entry)it.next();
            query += URLEncoder.encode((String) pairs.getKey(), "utf-8") + "=" +
                    URLEncoder.encode((String) pairs.getValue(), "utf-8");
            if (it.hasNext()) { query += "&"; }
        }
    }
*/




    public QueryString(Object name, Object value) throws UnsupportedEncodingException
    {
        query = URLEncoder.encode(name.toString(), "utf-8") + "=" +
                URLEncoder.encode(value.toString(), "utf-8");
    }

    public QueryString() { query = ""; }

    public synchronized void add(Object name, Object value) throws UnsupportedEncodingException
    {
        if (!query.trim().equals("")) query += "&";
        query += URLEncoder.encode(name.toString(), "utf-8") + "=" +
                URLEncoder.encode(value.toString(), "utf-8");
    }

    public String toString() { return query; }

    /**
     * Created by habeeb on 18/04/16.
     */
    public static class NetworkUnavailableException extends Exception
    {


    }
}