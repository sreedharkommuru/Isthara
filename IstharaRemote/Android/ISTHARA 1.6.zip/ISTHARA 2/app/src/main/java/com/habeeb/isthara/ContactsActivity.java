package com.habeeb.isthara;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.TextView;

/**
 * Created by habeeb on 13/09/17.
 */

public class ContactsActivity extends Activity {


    public  static final int CallRequestPermissionCode  = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts_layout);

        TextView topTitleTextView = (TextView) findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Isthara Contacts");


        callPermissionAction();

    }

    /*
    * CALL BUTTON ACTION
    * */
    public void callButtonAction(View view)
    {
        callNowAction("+91 8790858581");
    }

    /*
    * CALL NUMBER FROM APP
    * */
    private void callNowAction(String number)
    {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            callPermissionAction();
            return;
        }
        startActivity(intent);
    }

    /*
     * CALL PERMISSION FOR APP
     * */
    private void callPermissionAction()
    {
        if (Build.VERSION.SDK_INT > 22)
        {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CALL_PHONE))
            {

                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE}, CallRequestPermissionCode);

            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults)
    {


        switch (requestCode) {

            case CallRequestPermissionCode:
                if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED))
                {

                }

                break;
            default:
                break;
        }
    }



    /*
    * EMAIL TO ISTHARA
    * */
    public void mailToIsthara(View view)
    {
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:hello@isthara.com"));
        startActivity(intent);
    }


}
