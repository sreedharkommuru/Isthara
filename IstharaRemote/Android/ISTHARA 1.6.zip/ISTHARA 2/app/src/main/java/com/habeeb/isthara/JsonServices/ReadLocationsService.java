package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 16/12/17.
 */

public class ReadLocationsService
{
    public ArrayList locationsListArray = new ArrayList();
    public ArrayList locationsIDsListArray = new ArrayList();

    public void getLocationsData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String locationname = jsonObject.getString("locationname");
                        String locid = jsonObject.getString("locid");


                        if (locationname.length() != 0 && !locationname.contains("null"))
                        {
                            locationsListArray.add(locationname);
                            locationsIDsListArray.add(locid);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }
}
