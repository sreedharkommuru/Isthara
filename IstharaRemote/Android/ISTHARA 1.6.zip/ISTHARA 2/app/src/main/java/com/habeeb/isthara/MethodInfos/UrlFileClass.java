package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 01/01/16.
 */

public class UrlFileClass
{
    //static String baseURL = "http://10.0.0.15:8888/";

    static String baseURL = "http://sriayyappaconstructions.com/";

    //static String baseFolder = "Isthara";
    static String baseFolder = "Istharav2";

    static String maintenanceService = baseFolder+"/maintenanceClass.php";

    static String feedbackService = baseFolder+"/feedbackclass.php";

    static String eventPostService = baseFolder+"/eventsClass.php";

    static String referralPostService = baseFolder+"/referralsClass.php";

    static String foodMenuPostService = baseFolder+"/foodmenuclass.php";

    static String usersListPostService = baseFolder+"/userslistclass.php";

    static String adminListPostService = baseFolder+"/adimregistration.php";

    static String usersChatPostService = baseFolder+"/userschat.php";

    static String locationsPostService = baseFolder+"/locationsClass.php";

    static String foodMenuUploadService = baseFolder+"/foodmenuimage.php";

    public static String foodMenuImage = "http://sriayyappaconstructions.com/Istharav2/foodmenus/";


    /*
    * API URL LISTS
    * */
    static String baseApiURL = "https://app.homaso.in/tenantsinfo";


}
