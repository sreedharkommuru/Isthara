package com.habeeb.isthara;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by habeeb on 26/08/17.
 */

public class RegistrationActivity extends Activity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Registration");


    }
}