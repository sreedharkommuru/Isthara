package com.habeeb.isthara;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadEventsService;
import com.habeeb.isthara.JsonServices.ReadReferralsService;
import com.habeeb.isthara.MethodInfos.EventGetMethodInfo;
import com.habeeb.isthara.MethodInfos.ReferralsGetMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 13/09/17.
 */

public class EventDisplayActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    ListAdapter adapter;
    ListView listView;

    ArrayList datesListArray = new ArrayList();
    ArrayList messagesListArray = new ArrayList();
    ArrayList emptyListArray = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_display_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Current Events");

        getEventsDataService();

    }


    /*
    * GET REFERRALS DATA SERIVCE
    * */
    private void getEventsDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        EventGetMethodInfo eventGetMethodInfo = new EventGetMethodInfo();
        methodExecutor.execute(eventGetMethodInfo);


    }

    /*
   * LOAD EVENTS IN LIST
   * */
    private void loadEventsList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new ListAdapter(datesListArray,messagesListArray,emptyListArray,4);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);


            }
        });
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        readJsonData(result);
    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }

    /*
    * GET EVENTS JSON DATA
    * */
    private void readJsonData(String response)
    {
        ReadEventsService readEventsService = new ReadEventsService();
        readEventsService.getEventsData(response);

        datesListArray.addAll(readEventsService.datesListArray);
        messagesListArray.addAll(readEventsService.messagesListArray);

        if (datesListArray.size() != 0)
        {
            loadEventsList();
        }

    }

}
