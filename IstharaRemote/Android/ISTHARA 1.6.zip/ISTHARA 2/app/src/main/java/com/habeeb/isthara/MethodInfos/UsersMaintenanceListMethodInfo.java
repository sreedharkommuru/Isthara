package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 10/09/17.
 */

public class UsersMaintenanceListMethodInfo extends MethodInfo
{

    public UsersMaintenanceListMethodInfo(String userid)
    {
        params.put("userid",userid);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.maintenanceService;
    }
}
