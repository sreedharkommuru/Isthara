package com.habeeb.isthara;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.icu.text.SimpleDateFormat;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.Calendar;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.MethodInfos.DeleteFoodMenuMethodInfo;
import com.habeeb.isthara.MethodInfos.FoodImageMethodInfo;
import com.habeeb.isthara.MethodInfos.UrlFileClass;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by habeeb on 17/09/17.
 */

public class ManageFoodMenuActivity extends Activity implements MethodExecutor.TaskDelegate
{
    ArrayList dayListArray = new ArrayList();
    ArrayList datesListArray = new ArrayList();
    ArrayList emptyListArray = new ArrayList();

    ListAdapter adapter;
    ListView listView;

    private static int RESULT_LOAD_IMAGE = 1;
    private Bitmap imageBitMap;

    String uploadImageDate = "";

    /*
    * CALENDER PICKER OBJECTS
    * */
    private DatePicker datePicker;
    private Calendar calendar;
    private int year, month, day;

    Button foodEntryButton;


    ImageView foodImageView;
    String dateIsString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_menu_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Food Menu");


        foodEntryButton = (Button)findViewById(R.id.foodMenuDateButton);
        foodImageView = (ImageView)findViewById(R.id.foodImageView);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        getDatesOfMenu();




        if (datesListArray.size() != 0)
        {
            loadUsersList();

            uploadImageDate = datesListArray.get(0).toString();

            findViewById(R.id.imageAttachmentButton).setVisibility(View.VISIBLE);
        }
        else
        {
            findViewById(R.id.imageAttachmentButton).setVisibility(View.GONE);
        }
    }

    /*
    * OLD CREATION OF FOODS
    * */
    private void getDatesOfMenu()
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        java.text.SimpleDateFormat day = new java.text.SimpleDateFormat("EEEE");
        java.text.SimpleDateFormat date = new java.text.SimpleDateFormat("yyyy-MM-dd");

        for (int i = 0; i < 7; i++)
        {
            cal.add(Calendar.DAY_OF_WEEK, 1);
            dayListArray.add(day.format(cal.getTime()));
            datesListArray.add(date.format(cal.getTime()));
        }

        if (datesListArray.size() != 0)
        {
            dateIsString = datesListArray.get(0).toString();
        }
        else
        {
            dateIsString = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new Date());
        }

        loadImageViewData();

    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new ListAdapter(dayListArray,datesListArray,emptyListArray,0);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

                String dateIs = datesListArray.get(position).toString();

                foodEntryActivity(dateIs);

            }
        });
    }

    /*
    * FOOD ENTRY ACTIVITY
    * */
    private void foodEntryActivity(String date)
    {
        Intent intent = new Intent(this,FoodEntryActivity.class);
        intent.putExtra("date",date);
        intent.putExtra("entry","admin");
        startActivity(intent);
    }

    /*
    * ATTACH IMAGE ACTION
    * */
    public void attachImageButtonAction(View view)
    {

        loadImageView();


    }

    /*
    * IMAGE FROM GALLEY
    * */

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            try {
                imageBitMap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
            } catch (IOException e) {
                e.printStackTrace();
            }

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            //imageBitMap = BitmapFactory.decodeFile(picturePath);

            if (imageBitMap != null)
            {
                uploadImageToFoodMenu();
            }

            //ImageView imageView = (ImageView) findViewById(R.id.imgView);
            //imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }
    }


    /*
    * UPLOAD IMAGE TO FOOD MENU
    * */
    private void uploadImageToFoodMenu()
    {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        imageBitMap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
        byte [] byte_arr = stream.toByteArray();
        String image_str = Base64.encodeToString(byte_arr,0);

        uploadImageMethodInfo(image_str);

    }

    /*
    * UPLOAD FOOD MENU IMAGE METHOD INFO
    * */
    private void uploadImageMethodInfo(String imageFile)
    {
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        FoodImageMethodInfo foodImageMethodInfo = new FoodImageMethodInfo(imageFile,uploadImageDate);
        methodExecutor.execute(foodImageMethodInfo);

    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        finish();
    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }



    /*
    * FOOD MENU ENTRY BUTTON ACTION
    * */
    public void foodMenuEntryAction(View view)
    {
        setDate(view);
    }


    public void setDate(View view)
    {

        showDialog(999);

    }

    @Override
    protected Dialog onCreateDialog(int id)
    {



        if (id == 999)
        {

            DatePickerDialog picker = new DatePickerDialog(this, myDateListener, year, month, day);

            try {



                picker.getDatePicker().setMinDate(System.currentTimeMillis());



            }
            catch (Exception e)
            {
                e.printStackTrace();
            }



            return picker;
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {

            showDate(arg1, arg2+1, arg3);
        }
    };

    private void showDate(int year, int month, int day)
    {


        String dateIs = String.valueOf(new StringBuilder().append(year).append("-").append(month).append("-").append(day));

        foodEntryButton.setText("SELECT DATE FOR ENTRY");

        foodEntryButton.setText(dateIs);

        foodEntryActivity(dateIs);

    }

    /*
    * IMAGE VIEW LAYOUT
    * */

    private void loadImageView()
    {

        findViewById(R.id.imageViewLayout).setVisibility(View.VISIBLE);


    }

    private void loadImageViewData()
    {

        foodImageView.setImageBitmap(null);

        AsyncTask.execute(new Runnable() {
            @Override
            public void run()
            {
                getBitmapFromURL(UrlFileClass.foodMenuImage+dateIsString);
            }
        });
    }

    public Bitmap getBitmapFromURL(String src)
    {
        try
        {
            java.net.URL url = new java.net.URL(src);
            HttpURLConnection connection = (HttpURLConnection) url
                    .openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            final Bitmap myBitmap = BitmapFactory.decodeStream(input);

            if (myBitmap != null)
            {
                runOnUiThread(new Thread(new Runnable() {
                    @Override
                    public void run()
                    {
                        foodImageView.setImageBitmap(myBitmap);
                    }
                }));


            }

            return myBitmap;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public void deleteImageButtonAction(View view)
    {
        deleteImage();
    }

    /*
    * DELETE FOOD IMAGE
    * */
    private void deleteImage()
    {
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        DeleteFoodMenuMethodInfo deleteFoodMenuMethodInfo = new DeleteFoodMenuMethodInfo(dateIsString);

        methodExecutor.execute(deleteFoodMenuMethodInfo);
    }

    public void addNewImageButtonAction(View view)
    {
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, RESULT_LOAD_IMAGE);
    }
}
