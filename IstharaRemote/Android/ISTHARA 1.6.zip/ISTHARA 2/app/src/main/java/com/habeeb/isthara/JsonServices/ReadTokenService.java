package com.habeeb.isthara.JsonServices;

import com.habeeb.isthara.ApplicationClass;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by habeeb on 15/09/17.
 */

public class ReadTokenService
{



    /*{
        "success": true,
            "newToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1MDY2NjUxMDksImlhdCI6MTUwNTQ1NTUwOSwic3ViIjoic3VtYW50aCJ9.dK7AAWNxSV40IIp3MP5nu9CJrmeJBFF6MRNtWL_5BPs",
            "data": [
        {
            "leaseId": 1233,
                "JoiningDate": "2017-05-05T18:30:00.000Z",
                "name": "Hemant",
                "propertyName": "Sri Sai Shabarisha Executive Boys Hostel1-(Park - A)",
                "rent": 4000,
                "photo": "https://app.homaso.in/files/tenants/photos/null"
        },
        {
            "leaseId": 2365,
                "JoiningDate": "2017-02-14T18:30:00.000Z",
                "name": "D.Murali",
                "propertyName": "Sri Sai Shabarisha- temple- B",
                "rent": 4000,
                "photo": "https://app.homaso.in/files/tenants/photos/null"
        }
    ]
    }*/


    String token = "";
    public boolean success = false;
    public String leaseId = "";
    public String roomNumber = "";
    public String bedNumber = "";
    public String userName = "";

    public void readTokenData(String jsonData,String userRoomNumber,String userBedNumber)
    {
        if (jsonData.length() != 0)
        {

            try {

                JSONObject jsonArray = new JSONObject(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        success = jsonArray.getBoolean("success");

                        if (success)
                        {
                            token = jsonArray.getString("newToken");

                            JSONArray dataArray = jsonArray.optJSONArray("data");

                            if (jsonArray.length() != 0)
                            {

                                for (int j = 0; j < dataArray.length(); j++)
                                {
                                    JSONObject jsonDataObject = dataArray.getJSONObject(j);

                                    roomNumber = jsonDataObject.getString("roomNumber");
                                    bedNumber = jsonDataObject.getString("bedName");
                                    userName = jsonDataObject.getString("name");
                                    leaseId = jsonDataObject.getString("leaseId");

                                    if (roomNumber.equalsIgnoreCase(userRoomNumber) && bedNumber.equalsIgnoreCase(userBedNumber))
                                    {

                                        ApplicationClass.userRoomNumber = roomNumber;
                                        ApplicationClass.userBedNumber = bedNumber;
                                        ApplicationClass.userLoginName = userName;
                                        ApplicationClass.userLeaseID = leaseId;

                                        return;

                                    }


                                }

                            }


                        }

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }
    }

}
