package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 29/10/17.
 */

public class FoodImageMethodInfo extends MethodInfo
{

    public FoodImageMethodInfo(String foodimage,String dateis)
    {
        params.put("foodimage",foodimage);
        params.put("userid", ApplicationClass.userRoomNumber);
        params.put("dateis",dateis);

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.foodMenuUploadService;
    }
}
