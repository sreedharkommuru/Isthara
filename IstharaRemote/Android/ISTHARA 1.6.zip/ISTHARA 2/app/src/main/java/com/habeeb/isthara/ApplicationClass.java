package com.habeeb.isthara;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by habeeb on 08/09/17.
 */

public class ApplicationClass extends Application
{

    /*
    * LOCAL STORED KEYS
    * */
    public static String mobileNumber = "mobileNumber";
    public static String ROOMNUMBER = "RoomNumber";
    public static String BEDNAME = "BedName";

    public static String userMobileNumber = "";
    public static String userRoomNumber = "";
    public static String userBedNumber = "";
    public static String userLoginName = "";

    public static String deviceToken = "";

    public static String userLoginRole = "";
    public static String userLeaseID = "";

    @Override
    public void onCreate()
    {
        super.onCreate();
    }


    public static String getCurrentDate()
    {
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
        String currentDateTime = sdf1.format(new Date());

        return currentDateTime;
    }

    public static String getCurrentDateandTime()
    {
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = sdf1.format(new Date());

        return currentDateTime;
    }


    /*
    * EMPTY ALL OBJECTS
    * */
    public static void emptyAllObjects()
    {
        userLoginName = "";
        userBedNumber = "";
        userLoginRole = "";
        userLeaseID = "";
        userMobileNumber = "";
        userRoomNumber = "";
    }


    /*
    * STORE DATA IN LOCAL
    * */
    public static void storeLocalData(Context context,String key,String value)
    {
        SharedPreferences sharedpreferences = context.getSharedPreferences("LocalStorage", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();

        editor.putString(key, value);

        editor.apply();
        editor.commit();

    }

    /*
    * GET LOCAL STORE DATA
    * */
    public static String getLocalData(Context context,String key)
    {
        SharedPreferences sharedpreferences = context.getSharedPreferences("LocalStorage", Context.MODE_PRIVATE);
        String valueString = sharedpreferences.getString(key,"");

        return valueString;
    }


    /*Select *
    from feedback AS fdb
    INNER JOIN userslist AS usr ON fdb.userid = usr.userid


    Select *
    from feedback AS fdb
    INNER JOIN userslist AS usr ON fdb.userid = usr.userid
    WHERE usr.userid = '8181' and fdb.userid = '8181'*/


    //CPANEL PASS - Sisir@09

    //https://www.simplifiedcoding.net/firebase-cloud-messaging-android/
    //https://inducesmile.com/android/android-push-notifications-using-google-cloud-messaging-gcm-php-mysql-and-okhttp-square-open-source/
}
