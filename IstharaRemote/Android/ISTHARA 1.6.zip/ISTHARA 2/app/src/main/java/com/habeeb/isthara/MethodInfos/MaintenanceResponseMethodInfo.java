package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 10/09/17.
 */

public class MaintenanceResponseMethodInfo extends MethodInfo
{

    public MaintenanceResponseMethodInfo(String id, String responseString)
    {
        params.put("userid",id);
        params.put("adminid", ApplicationClass.userRoomNumber);
        params.put("response",responseString);
        params.put("insdate", ApplicationClass.getCurrentDateandTime());

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.maintenanceService;
    }
}
