package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 20/09/17.
 */

public class FeedbackReponseMethodInfo extends MethodInfo
{

    public FeedbackReponseMethodInfo(String userID, String messageString)
    {

        params.put("userid",userID);
        params.put("adminid",ApplicationClass.userRoomNumber);
        params.put("adminmessage",messageString);
        params.put("insdate", ApplicationClass.getCurrentDateandTime());

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.feedbackService;
    }
}