package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 16/09/17.
 */

public class OTPVerifyMethodInfo extends MethodInfo
{

    public OTPVerifyMethodInfo(String number,String otpNumber)
    {

        params.put("phoneNumber",number);
        params.put("type","verifyOtp");
        params.put("sendOtp",otpNumber);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.baseApiURL;
    }
}
