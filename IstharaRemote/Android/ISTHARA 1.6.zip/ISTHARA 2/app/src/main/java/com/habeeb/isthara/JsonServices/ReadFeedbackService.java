package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 15/09/17.
 */

public class ReadFeedbackService
{

    public ArrayList usersListArray = new ArrayList();
    public ArrayList usersIDsListArray = new ArrayList();
    public ArrayList messagesListArray = new ArrayList();
    public ArrayList feedbackIDListArray = new ArrayList();
    public ArrayList feedbackStatusListArray = new ArrayList();
    public ArrayList roomnumberListArray = new ArrayList();
    public ArrayList datesListArray = new ArrayList();


    public ArrayList userMessageList = new ArrayList();
    public ArrayList adminMessageList = new ArrayList();
    public ArrayList adminNameList = new ArrayList();

    public void getFeedbackData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String userid = jsonObject.getString("userid");
                        String message = jsonObject.getString("message");

                        String bednumber = jsonObject.getString("bednumber");
                        String username = jsonObject.getString("username");
                        String fid = jsonObject.getString("fid");
                        String readstatus = jsonObject.getString("readstatus");
                        String date = jsonObject.getString("date");

                        String[] separated = date.split(" ");
                        date = separated[0];

                        userid = userid.trim();
                        message = message.trim();


                        if (message.length() != 0 && !message.contains("null"))
                        {
                            if (!usersIDsListArray.contains(userid))
                            {
                                messagesListArray.add(message);
                                usersListArray.add(username);
                                feedbackIDListArray.add(fid);
                                feedbackStatusListArray.add(readstatus);
                                usersIDsListArray.add(userid);
                                roomnumberListArray.add(bednumber);
                                datesListArray.add(date);
                            }



                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }

    /*
    * USERS FEEDBACK
    * */
    public void getUsersFeedbackData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String userid = jsonObject.getString("userid");
                        String message = jsonObject.getString("message");
                        String adminmessage = jsonObject.getString("adminmessage");
                        String username = jsonObject.getString("username");
                        String date = jsonObject.getString("date");

                        //String[] separated = date.split(" ");
                        //date = separated[0];

                        message = message.trim();

                        userMessageList.add(message);
                        adminMessageList.add(adminmessage);

                        if (adminmessage.length() != 0)
                        {
                            adminNameList.add("("+username+"/"+date+")");
                            datesListArray.add("");
                        }
                        else
                        {
                            adminNameList.add("");
                            datesListArray.add("("+date+")");
                        }

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }

}


