package com.habeeb.isthara;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by habeeb on 06/01/16.
 */
public class ToastClass
{

    Toast toastobject;

    public void ToastCalled(Context context, String message)
    {

        if (toastobject != null)
        {
            toastobject.cancel();
        }

        toastobject = Toast.makeText(context,message,Toast.LENGTH_SHORT);

        toastobject.show();
    }
}
