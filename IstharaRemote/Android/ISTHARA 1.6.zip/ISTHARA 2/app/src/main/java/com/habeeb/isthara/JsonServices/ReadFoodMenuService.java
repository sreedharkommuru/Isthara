package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 17/09/17.
 */

public class ReadFoodMenuService
{
    /*    [{"foodid":"1",
        "breakfastitems":"Idly, Wada and Puri",
        "dinneritems":"Mutton Briyani with Tomato masala",
        "menudate":"2017-09-18"}]

*/

    public String breakFastString = "";
    public String dinnerString = "";

    public ArrayList datesofMenu = new ArrayList();


    public void getMenuData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        breakFastString = jsonObject.getString("breakfastitems");
                        dinnerString = jsonObject.getString("dinneritems");

                        breakFastString = breakFastString.trim();
                        dinnerString = dinnerString.trim();

                        if (breakFastString.length() == 0)
                        {
                            breakFastString = "No Break Fast";
                        }

                        if (dinnerString.length() == 0)
                        {
                            dinnerString = "No Dinner";
                        }

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }


    /*
    * GET ALL DATES
    * */
    public void getMenuDates(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {

                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        datesofMenu.add(jsonObject.getString("menudate"));

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }
}
