package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 07/01/18.
 */

public class LocationUpdateMethodInfo extends MethodInfo
{

    public LocationUpdateMethodInfo(String locationName,String userid,String locationID)
    {
        params.put("locationID",locationID);
        params.put("userid",userid);
        params.put("update","update");
        params.put("locationname",locationName);

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.locationsPostService;
    }
}
