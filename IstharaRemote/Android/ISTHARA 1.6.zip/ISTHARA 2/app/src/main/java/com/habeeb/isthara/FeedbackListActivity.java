package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadFeedbackService;
import com.habeeb.isthara.MethodInfos.FeedbackGetMethodInfo;
import com.habeeb.isthara.MethodInfos.FeedbackReponseMethodInfo;

import java.util.ArrayList;


/**
 * Created by habeeb on 08/09/17.
 */

public class FeedbackListActivity extends Activity implements MethodExecutor.TaskDelegate
{

    int serviceCount = 0;
    ToastClass toastClass = new ToastClass();

    AdminListAdapter adapter;
    ListView listView;


    ArrayList userNamesList = new ArrayList();
    ArrayList userMessageList = new ArrayList();
    ArrayList feedbackIDListArray = new ArrayList();
    ArrayList feedbackStatusListArray = new ArrayList();
    ArrayList usersIDsListArray = new ArrayList();
    ArrayList datesListArray = new ArrayList();
    ArrayList roomnumbersListArray = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Feedback List");


        getFeedbackDataService();




    }


    /*
    * GET FEEDBACK DATA SERIVCE
    * */
    private void getFeedbackDataService()
    {

        serviceCount = 0;
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        FeedbackGetMethodInfo feedbackGetMethodInfo = new FeedbackGetMethodInfo();
        methodExecutor.execute(feedbackGetMethodInfo);


    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new AdminListAdapter(userNamesList);

        adapter.list1Array = new ArrayList();
        adapter.list1Array.addAll(roomnumbersListArray);

        adapter.list2Array = new ArrayList();
        adapter.list2Array.addAll(datesListArray);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

                feedBackHistoryAction(position);

                /*if (feedbackStatusListArray.get(position).toString().equalsIgnoreCase("0"))
                {
                    alertResponseDialog(feedbackIDListArray.get(position).toString());
                }*/





            }
        });
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readJsonData(result);
        }
        else
        {
            toastClass.ToastCalled(this,result);
            finish();
        }


    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }

    /*
    * GET FEEDBACK JSON DATA
    * */
    private void readJsonData(String response)
    {
        ReadFeedbackService readFeedbackService = new ReadFeedbackService();
        readFeedbackService.getFeedbackData(response);


        userNamesList.addAll(readFeedbackService.usersListArray);
        userMessageList.addAll(readFeedbackService.messagesListArray);
        feedbackIDListArray.addAll(readFeedbackService.feedbackIDListArray);
        feedbackStatusListArray.addAll(readFeedbackService.feedbackStatusListArray);
        usersIDsListArray.addAll(readFeedbackService.usersIDsListArray);
        datesListArray.addAll(readFeedbackService.datesListArray);
        roomnumbersListArray.addAll(readFeedbackService.roomnumberListArray);

        if (userNamesList.size() != 0)
        {
            loadUsersList();
        }


    }


    /*
    * GET FEEDBACK DATA SERIVCE
    * */
    private void responseToFeedbackDataService(String responseID)
    {

        serviceCount = 1;
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        FeedbackReponseMethodInfo feedbackReponseMethodInfo = new FeedbackReponseMethodInfo(ApplicationClass.userLoginRole,responseID);
        methodExecutor.execute(feedbackReponseMethodInfo);


    }


    /*
    * ALERT DIALOG FOR RESPONSE
    * */
    private void alertResponseDialog(final String responseID)
    {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setCancelable(false);

        TextView text = new TextView(this);
        text.setTextColor(Color.WHITE);
        text.setText("RESPONSE");
        text.setBackgroundColor(this.getResources().getColor(R.color.colorGrey));
        text.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        alertDialog.setCustomTitle(text);

        alertDialog.setMessage("Have you read this feedback?");

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        responseToFeedbackDataService(responseID);
                    }
                });

        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }


    /*
    * OPEN FEEDBACK HISTORY LIST
    * */
    private void feedBackHistoryAction(int indexPosition)
    {
        Intent intent = new Intent(this,FeedbackChatActivity.class);
        intent.putExtra("userID",usersIDsListArray.get(indexPosition).toString());
        intent.putExtra("userName",userNamesList.get(indexPosition).toString()+"/"+roomnumbersListArray.get(indexPosition).toString());
        startActivity(intent);
    }

}
