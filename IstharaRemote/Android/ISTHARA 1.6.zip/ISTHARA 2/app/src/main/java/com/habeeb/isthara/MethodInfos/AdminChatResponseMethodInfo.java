package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 20/12/17.
 */

public class AdminChatResponseMethodInfo extends MethodInfo
{

    public AdminChatResponseMethodInfo(String id, String responseString,int uid)
    {
        if (uid == 1)
        {
            params.put("userid",id);
            params.put("message",responseString);
            params.put("insdate", ApplicationClass.getCurrentDateandTime());
            params.put("notificationTitle",ApplicationClass.userBedNumber);
        }
        else
        {
            params.put("userid",id);
            params.put("adminid", ApplicationClass.userRoomNumber);
            params.put("adminmessage",responseString);
            params.put("insdate", ApplicationClass.getCurrentDateandTime());
            params.put("notificationTitle","Admin Message");
        }


    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.usersChatPostService;
    }
}
