package com.habeeb.isthara;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadMaintenanceService;
import com.habeeb.isthara.MethodInfos.MaintenancePostMethodInfo;
import com.habeeb.isthara.MethodInfos.UsersMaintenanceListMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 10/09/17.
 */

public class UsersMaintenanceActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    ListAdapter adapter;
    ListView listView;

    ArrayList messagesList = new ArrayList();
    ArrayList responseMessagesList = new ArrayList();
    ArrayList respondedByList = new ArrayList();
    ArrayList datesList = new ArrayList();

    String responseString, idString;

    String userMessageString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_list_maintenance_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Maintenance List");

        findViewById(R.id.moreButton).setVisibility(View.GONE);





    }


    /*
    * POST MAINTENANCE DATA SERIVCE
    * */
    private void getMaintenanceDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        UsersMaintenanceListMethodInfo usersFeedbackListMethodInfo = new UsersMaintenanceListMethodInfo(ApplicationClass.userLeaseID);
        methodExecutor.execute(usersFeedbackListMethodInfo);


    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new ListAdapter(messagesList,responseMessagesList,respondedByList,2);

        adapter.list4rdArray = new ArrayList();
        adapter.list4rdArray.addAll(datesList);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

            }
        });

        listView.setSelection(listView.getAdapter().getCount()-1);
        this.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readJsonData(result);
        }
        else if (serviceCount == 1)
        {
            getMaintenanceDataService();
        }
        else
        {
            toastClass.ToastCalled(this,result);
            finish();
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }

    /*
    * GET MAINTENANCE JSON DATA
    * */
    private void readJsonData(String response)
    {

        messagesList.clear();
        responseMessagesList.clear();
        respondedByList.clear();
        datesList.clear();

        ReadMaintenanceService readMaintenanceService = new ReadMaintenanceService();
        readMaintenanceService.getUsersMaintenanceData(response);


        messagesList.addAll(readMaintenanceService.messagesListArray);
        responseMessagesList.addAll(readMaintenanceService.responseMessageList);
        respondedByList.addAll(readMaintenanceService.respondedByListArray);
        datesList.addAll(readMaintenanceService.datesList);

        if (messagesList.size() != 0)
        {
            loadUsersList();
        }

    }


    /*
    * ADD FEEDBACK ACTION
    * */
    public void addButtonAction(View view)
    {

    }


    @Override
    protected void onResume()
    {
        getMaintenanceDataService();
        super.onResume();
    }

    /*
    * SEND MESSAGE EDIT TEXT VIEW
    * */
    public void getMessageSendAction(View view)
    {
        EditText userMessageEditText = (EditText)findViewById(R.id.userMessageEditText);
        userMessageString = userMessageEditText.getText().toString().trim();

        if (userMessageString.length() != 0)
        {
           postMaintenanceDataService();
        }
        else
        {
            toastClass.ToastCalled(this,"Required Message");
            userMessageEditText.requestFocus();
        }

    }

    /*
    * POST USER MESSAGE
    * */
    public void postMaintenanceDataService()
    {

        serviceCount = 1;

        EditText userMessageEditText = (EditText)findViewById(R.id.userMessageEditText);
        userMessageEditText.setText("");

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);


        MaintenancePostMethodInfo maintenancePostMethodInfo = new MaintenancePostMethodInfo(ApplicationClass.userMobileNumber,userMessageString);
        methodExecutor.execute(maintenancePostMethodInfo);

    }
}
