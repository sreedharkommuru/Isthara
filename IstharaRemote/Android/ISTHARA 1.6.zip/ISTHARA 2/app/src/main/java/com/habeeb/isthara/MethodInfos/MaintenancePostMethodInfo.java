package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 01/01/16.
 */

public class MaintenancePostMethodInfo extends MethodInfo
{

    public MaintenancePostMethodInfo(String userID, String messageString)
    {
        params.put("userid",ApplicationClass.userLeaseID);
        params.put("message",messageString);
        params.put("insdate", ApplicationClass.getCurrentDateandTime());
        params.put("notificationTitle", "BedNumber - " +ApplicationClass.userBedNumber);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.maintenanceService;
    }
}