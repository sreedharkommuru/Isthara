package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 16/09/17.
 */

public class EventGetMethodInfo extends MethodInfo
{

    public EventGetMethodInfo()
    {
        String date = ApplicationClass.getCurrentDate();
        params.put("date",date);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.eventPostService;
    }
}