package com.habeeb.isthara;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadMaintenanceService;
import com.habeeb.isthara.JsonServices.ReadReferralsService;
import com.habeeb.isthara.MethodInfos.MaintenanceGetMethodInfo;
import com.habeeb.isthara.MethodInfos.ReferralsGetMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 15/09/17.
 */

public class SalesReferralsListActivity extends Activity implements MethodExecutor.TaskDelegate
{
    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    AdminListAdapter adapter;
    ListView listView;

    ArrayList userIDsListArray = new ArrayList();
    ArrayList NameList = new ArrayList();
    ArrayList contactsList = new ArrayList();
    ArrayList usersList = new ArrayList();
    ArrayList locationListArray = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Sales Referrals List");

        getReferralsDataService();



    }


    /*
    * GET REFERRALS DATA SERIVCE
    * */
    private void getReferralsDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        ReferralsGetMethodInfo referralsGetMethodInfo = new ReferralsGetMethodInfo();
        methodExecutor.execute(referralsGetMethodInfo);


    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {


        listView = (ListView)findViewById(R.id.listView);

        adapter= new AdminListAdapter(NameList);

        adapter.list1Array = new ArrayList();
        adapter.list1Array.addAll(contactsList);

        adapter.list2Array = new ArrayList();
        adapter.list2Array.addAll(usersList);

        adapter.list3Array = new ArrayList();
        adapter.list3Array.addAll(locationListArray);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {



            }
        });

        /*listView = (ListView)findViewById(R.id.listView);

        adapter= new ListAdapter(NameList,contactsList,userIDsListArray,4);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);


            }
        });*/
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readJsonData(result);
        }
        else
        {
            toastClass.ToastCalled(this,result);
            finish();
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }

    /*
    * GET FEEDBACK JSON DATA
    * */
    private void readJsonData(String response)
    {
        ReadReferralsService referralsService = new ReadReferralsService();
        referralsService.getReferralsData(response);

        NameList.addAll(referralsService.namesListArray);
        contactsList.addAll(referralsService.contactsListArray);
        usersList.addAll(referralsService.usersListArray);
        locationListArray.addAll(referralsService.locationListArray);

        if (NameList.size() != 0)
        {
            loadUsersList();
        }

    }


}
