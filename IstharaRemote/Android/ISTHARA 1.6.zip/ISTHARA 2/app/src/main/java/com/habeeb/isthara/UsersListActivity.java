package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadFeedbackService;
import com.habeeb.isthara.JsonServices.ReadUsersListService;
import com.habeeb.isthara.MethodInfos.UsersListMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 29/10/17.
 */

public class UsersListActivity extends Activity implements MethodExecutor.TaskDelegate
{

    int serviceCount = 0;
    ToastClass toastClass = new ToastClass();

    AdminListAdapter adapter;
    ListView listView;


    ArrayList userNamesList = new ArrayList();
    ArrayList usersIDsListArray = new ArrayList();
    ArrayList roomNumbersList = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Users List");


        getUsersListService();

    }


    /*
    * GET FEEDBACK DATA SERIVCE
    * */
    private void getUsersListService()
    {

        serviceCount = 0;
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        UsersListMethodInfo usersListMethodInfo = new UsersListMethodInfo(ApplicationClass.userRoomNumber);
        methodExecutor.execute(usersListMethodInfo);


    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new AdminListAdapter(userNamesList);

        adapter.list1Array = new ArrayList();
        adapter.list1Array.addAll(roomNumbersList);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

                userChatHistoryAction(position);





            }
        });
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readJsonData(result);
        }
        else
        {
            toastClass.ToastCalled(this,result);
            finish();
        }


    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }

    /*
    * GET FEEDBACK JSON DATA
    * */
    private void readJsonData(String response)
    {
        ReadUsersListService readUsersListService = new ReadUsersListService();
        readUsersListService.getUsersListData(response);


        userNamesList.addAll(readUsersListService.userNameArray);
        usersIDsListArray.addAll(readUsersListService.userIDArray);
        roomNumbersList.addAll(readUsersListService.roomNumbersList);

        if (userNamesList.size() != 0)
        {
            loadUsersList();
        }


    }


    /*
    * OPEN USER CHAT HISTORY LIST
    * */
    private void userChatHistoryAction(int indexPosition)
    {
        Intent intent = new Intent(this,AdminUserChatActivity.class);
        intent.putExtra("userID",usersIDsListArray.get(indexPosition).toString());
        intent.putExtra("userName",userNamesList.get(indexPosition).toString());
        startActivity(intent);
    }

}
