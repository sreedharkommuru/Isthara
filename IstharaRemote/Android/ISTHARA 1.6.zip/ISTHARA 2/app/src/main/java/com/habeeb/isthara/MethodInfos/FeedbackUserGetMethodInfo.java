package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 26/10/17.
 */

public class FeedbackUserGetMethodInfo extends MethodInfo
{

    public FeedbackUserGetMethodInfo(String userid)
    {
        params.put("userid",userid);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.feedbackService;
    }
}
