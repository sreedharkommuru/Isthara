package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 17/09/17.
 */

public class FoodMenuEntryMethodInfo extends MethodInfo
{

    public FoodMenuEntryMethodInfo(String breakfast, String dinner,String dateis)
    {
        params.put("breakfast",breakfast);
        params.put("dinner",dinner);
        params.put("insdate",dateis);

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.foodMenuPostService;
    }
}