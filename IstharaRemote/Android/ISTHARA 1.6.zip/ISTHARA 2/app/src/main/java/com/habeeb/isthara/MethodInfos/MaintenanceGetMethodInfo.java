package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 10/09/17.
 */

public class MaintenanceGetMethodInfo extends MethodInfo
{

    public MaintenanceGetMethodInfo()
    {
        params.put("admin","admin");
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.maintenanceService;
    }
}
