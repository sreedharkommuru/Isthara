package com.habeeb.isthara.MethodInfos;

import android.util.Log;

import org.json.JSONObject;

import java.util.LinkedHashMap;

/**
 * Created by habeeb on 18/04/16.
 */ public abstract class MethodInfo
{

    protected LinkedHashMap<String,Object> params = new LinkedHashMap<String,Object>();

    protected int serviceLogCount = 0;


    public abstract String getRequestType();

    protected abstract String getEndPoint();

    public String getURL() throws Exception
    {

        if (getEndPoint().contains("https"))
        {
            if (getRequestType() == "GET")
            {

                try
                {
                    QueryString queryString = new QueryString(params);

                    return getEndPoint()+"/"+queryString;

                }
                catch (Exception e)
                {
                    System.out.print(e);
                }
            }

            return  getEndPoint();

        }
        else if (getRequestType() == "POST")
        {
            return  UrlFileClass.baseURL+getEndPoint();
        }
        else if (getRequestType() == "GET")
        {

            try
            {
                QueryString queryString = new QueryString(params);

                return UrlFileClass.baseURL+getEndPoint()+queryString;

            }
            catch (Exception e)
            {
                System.out.print(e);
            }
        }


        throw new Exception("Unsupported request type"+getRequestType());


    }

    public String getRequestBody()
    {

        if (params.size() == 0)
        {
            return "";
        }

        JSONObject jsonObject = new JSONObject(params);

        String result = jsonObject.toString();

        Log.d("Get request body ", result);

        return result;

    }


    public int serviceLog()
    {
        return serviceLogCount;
    }



}
