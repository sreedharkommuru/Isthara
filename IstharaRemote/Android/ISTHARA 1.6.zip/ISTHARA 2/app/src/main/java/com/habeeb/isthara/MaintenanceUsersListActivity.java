package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadMaintenanceService;
import com.habeeb.isthara.MethodInfos.MaintenanceGetMethodInfo;
import com.habeeb.isthara.MethodInfos.MaintenanceResponseMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 10/09/17.
 */

public class MaintenanceUsersListActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    AdminListAdapter adapter;
    ListView listView;

    ArrayList idsListArray = new ArrayList();
    ArrayList roomNumbersList = new ArrayList();
    ArrayList messagesList = new ArrayList();
    ArrayList respondedByList = new ArrayList();
    ArrayList userNamesList = new ArrayList();
    ArrayList datesList = new ArrayList();

    ArrayList statusListArray = new ArrayList();

    String responseString, idString;

    String maintenanceResponse = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maintenace_list_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Maintenance Users List");

        findViewById(R.id.rightButton).setVisibility(View.GONE);

        findViewById(R.id.statusSpinner).setVisibility(View.GONE);



        getMaintenanceDataService();



    }


    /*
    * GET MAINTENANCE DATA SERIVCE
    * */
    private void getMaintenanceDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        MaintenanceGetMethodInfo feedbackGetMethodInfo = new MaintenanceGetMethodInfo();
        methodExecutor.execute(feedbackGetMethodInfo);


    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new AdminListAdapter(userNamesList);

        adapter.list1Array = new ArrayList();
        adapter.list1Array.addAll(roomNumbersList);

        adapter.list2Array = new ArrayList();
        adapter.list2Array.addAll(datesList);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

                idString = idsListArray.get(position).toString();

                openMessageListActivity(position);

            }
        });



    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            maintenanceResponse = result;
            getAllUsersData(result);
            //readJsonData(result,"");
        }
        else
        {
            toastClass.ToastCalled(this,result);
            finish();
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }

    /*
    * GET ALL MAINTENANCE USERS DATA
    * */
    private void getAllUsersData(String response)
    {
        roomNumbersList.clear();
        messagesList.clear();
        idsListArray.clear();
        respondedByList.clear();
        userNamesList.clear();
        datesList.clear();

        ReadMaintenanceService readMaintenanceService = new ReadMaintenanceService();
        readMaintenanceService.getMaintenanceUsersData(response);

        roomNumbersList.addAll(readMaintenanceService.roomNumberList);
        userNamesList.addAll(readMaintenanceService.usersListArray);
        idsListArray.addAll(readMaintenanceService.userIDListArray);
        respondedByList.addAll(readMaintenanceService.respondedByListArray);
        datesList.addAll(readMaintenanceService.datesList);

        if (roomNumbersList.size() != 0)
        {
            loadUsersList();
        }
    }




    /*
    * USER ALL MESSAGE LIST ACTIVITY
    * */
    private void openMessageListActivity(int indexPosition)
    {
        Intent intent = new Intent(this,MaintenanceAdminResponseActivity.class);
        intent.putExtra("userID",idsListArray.get(indexPosition).toString());
        intent.putExtra("userName",userNamesList.get(indexPosition).toString()+"/"+roomNumbersList.get(indexPosition).toString());
        startActivity(intent);

    }

}
