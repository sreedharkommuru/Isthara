package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 14/09/17.
 */

public class PostReferralMethodInfo extends MethodInfo
{

    public PostReferralMethodInfo(String userID,String nameString,String numberString,String location)
    {
        params.put("userid", ApplicationClass.userLeaseID);
        params.put("referralname",nameString);
        params.put("referralnumber",numberString);
        params.put("insDate",ApplicationClass.getCurrentDateandTime());
        params.put("location",location);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.referralPostService;
    }
}