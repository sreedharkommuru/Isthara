package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 15/09/17.
 */

public class ReferralsGetMethodInfo extends MethodInfo
{

    public ReferralsGetMethodInfo()
    {
        params.put("admin","admin");
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.referralPostService;
    }
}
