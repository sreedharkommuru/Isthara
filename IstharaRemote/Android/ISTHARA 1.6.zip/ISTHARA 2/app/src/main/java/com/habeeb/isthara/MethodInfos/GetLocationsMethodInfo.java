package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 16/12/17.
 */

public class GetLocationsMethodInfo extends MethodInfo
{

    public GetLocationsMethodInfo()
    {
        params.put("locations","locations");
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.referralPostService;
    }
}
