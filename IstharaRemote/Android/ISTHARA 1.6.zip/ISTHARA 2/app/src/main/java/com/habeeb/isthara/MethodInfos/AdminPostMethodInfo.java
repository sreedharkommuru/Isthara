package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 30/09/17.
 */

public class AdminPostMethodInfo extends MethodInfo
{

    public AdminPostMethodInfo(String userid,String phoneNumber)
    {
        params.put("userid", userid);
        params.put("phonenumber",phoneNumber);
        params.put("devicetoken",ApplicationClass.deviceToken);

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.adminListPostService;
    }
}
