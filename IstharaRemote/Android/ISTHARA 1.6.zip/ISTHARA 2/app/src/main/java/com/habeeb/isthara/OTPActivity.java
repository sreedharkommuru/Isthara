package com.habeeb.isthara;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadOTPService;
import com.habeeb.isthara.MethodInfos.OTPVerifyMethodInfo;

/**
 * Created by habeeb on 16/09/17.
 */

public class OTPActivity extends Activity implements MethodExecutor.TaskDelegate
{

    int serviceCount = 0;

    ToastClass toastClass = new ToastClass();
    String otpNumber = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Verify OTP");
    }


    /*
    * OTP SUBMIT BUTTON ACTION
    * */
    public void otpButtonAction(View view)
    {
        EditText otpEditText = (EditText)findViewById(R.id.otpnumberEditText);

        otpNumber = otpEditText.getText().toString().trim();

        if (otpNumber.length() == 0)
        {
            toastClass.ToastCalled(this,"Required OTP");
            return;
        }
        else
        {
            verifyOTPService();
        }
    }

    /*
    * VERIFY OTP SERVICE METHOD INFO
    * */
    private void verifyOTPService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        OTPVerifyMethodInfo otpVerifyMethodInfo = new OTPVerifyMethodInfo(ApplicationClass.userMobileNumber,otpNumber);
        methodExecutor.execute(otpVerifyMethodInfo);

    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readResponseData(result);
        }


    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }


    /*
    * READ RESPONSE DATA
    * */
    private void readResponseData(String response)
    {
        ReadOTPService readOTPService = new ReadOTPService();
        readOTPService.readOTPData(response);

        if (readOTPService.success)
        {
            finish();
        }
        else
        {
            toastClass.ToastCalled(this,"OTP failed to verify");
            return;
        }

    }

}
