package com.habeeb.isthara;

import android.app.Activity;
import android.content.Intent;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.habeeb.isthara.FoodEntryActivity;
import com.habeeb.isthara.JsonServices.ReadFoodMenuService;
import com.habeeb.isthara.ListAdapter;
import com.habeeb.isthara.MethodInfos.FoodMenuGetMethodInfo;
import com.habeeb.isthara.MethodInfos.UrlFileClass;
import com.habeeb.isthara.R;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by habeeb on 17/09/17.
 */

public class UserFoodMenuActivity extends Activity implements MethodExecutor.TaskDelegate
{

    int serviceCount = 0;

    ArrayList dayListArray = new ArrayList();
    ArrayList datesListArray = new ArrayList();
    ArrayList emptyListArray = new ArrayList();

    ArrayList weekDatesArray = new ArrayList();

    ListAdapter adapter;
    ListView listView;

    String dateIsString = "";

    Button foodMenuDateButton;

    ImageView foodImageView;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_food_menu_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Food Menu");

        getDatesOfMenu();

        if (weekDatesArray.size() != 0)
        {
            dateIsString = weekDatesArray.get(0).toString();
        }
        else
        {
            dateIsString = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        }



        foodMenuDateButton = (Button)findViewById(R.id.foodMenuDateButton);
        foodMenuDateButton.setVisibility(View.GONE);

        foodImageView = (ImageView)findViewById(R.id.foodImageView);

        getDataMethodInfo();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run()
            {
                getBitmapFromURL(UrlFileClass.foodMenuImage+dateIsString);
            }
        });


    }


    /*
    * OLD CREATION OF FOODS
    * */
    private void getDatesOfMenu()
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        SimpleDateFormat day = new SimpleDateFormat("EEEE");
        //SimpleDateFormat date = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");

        for (int i = 0; i < 7; i++)
        {
            cal.add(Calendar.DAY_OF_WEEK, 1);
            weekDatesArray.add(date.format(cal.getTime()));

        }

    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        adapter= new ListAdapter(datesListArray,emptyListArray,emptyListArray,0);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

                String dateIs = datesListArray.get(position).toString();

                foodEntryActivity(dateIs);

            }
        });
    }

    /*
    * FOOD ENTRY ACTIVITY
    * */
    private void foodEntryActivity(String date)
    {
        Intent intent = new Intent(this,FoodEntryActivity.class);
        intent.putExtra("date",date);
        intent.putExtra("entry","user");
        startActivity(intent);
    }


    /*
   * GET DATA METHOD INFO
   * */
    private void getDataMethodInfo()
    {

        serviceCount = 1;
        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        FoodMenuGetMethodInfo foodMenuGetMethodInfo = new FoodMenuGetMethodInfo(dateIsString,1);
        methodExecutor.execute(foodMenuGetMethodInfo);
    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 1)
        {
            readResponseData(result);
        }
    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }


    /*
    * READ RESPONSE DATA
    * */
    private void readResponseData(String response)
    {
        ReadFoodMenuService readFoodMenuService = new ReadFoodMenuService();
        readFoodMenuService.getMenuDates(response);

        datesListArray.clear();
        datesListArray.addAll(readFoodMenuService.datesofMenu);


        if (datesListArray.size() != 0)
        {
            loadUsersList();
        }
        else
        {
            if(foodImageView.getDrawable() == null)
            {
                foodMenuDateButton.setText("Menu will be available soon...");
                foodMenuDateButton.setVisibility(View.VISIBLE);
                foodMenuDateButton.setEnabled(false);
            }

        }

    }


    public Bitmap getBitmapFromURL(String src)
    {
        try
        {
            java.net.URL url = new java.net.URL(src);
            HttpURLConnection connection = (HttpURLConnection) url
                    .openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            final Bitmap myBitmap = BitmapFactory.decodeStream(input);

            if (myBitmap != null)
            {
                runOnUiThread(new Thread(new Runnable() {
                    @Override
                    public void run()
                    {
                        foodImageView.setImageBitmap(myBitmap);
                        foodMenuDateButton.setVisibility(View.GONE);
                        if (listView != null)
                        {
                            listView.setVisibility(View.GONE);
                        }
                    }
                }));


            }

            return myBitmap;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }
}