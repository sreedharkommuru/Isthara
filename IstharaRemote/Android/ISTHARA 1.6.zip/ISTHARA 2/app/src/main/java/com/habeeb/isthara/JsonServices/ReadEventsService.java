package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 16/09/17.
 */

public class ReadEventsService
{

    public ArrayList datesListArray = new ArrayList();
    public ArrayList messagesListArray = new ArrayList();

    public void getEventsData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String evdate = jsonObject.getString("evdate");
                        String evmessage = jsonObject.getString("evmessage");

                        evdate = evdate.trim();
                        evmessage = evmessage.trim();

                        if (evdate.length() != 0 && !evdate.contains("null"))
                        {
                            messagesListArray.add(evmessage);
                            datesListArray.add(evdate);

                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }
}
