package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by habeeb on 30/09/17.
 */

public class ReadAdminService
{

    public String admuserid = "";
    public String admphonenumber = "";
    public String admusername = "";

    public void getAdminData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String userid = jsonObject.getString("userid");
                        String phonenumber = jsonObject.getString("phonenumber");
                        String username = jsonObject.getString("username");

                        if (userid.length() != 0)
                        {
                            admuserid = userid;
                            admphonenumber = phonenumber;
                            admusername = username;
                        }



                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }

}
