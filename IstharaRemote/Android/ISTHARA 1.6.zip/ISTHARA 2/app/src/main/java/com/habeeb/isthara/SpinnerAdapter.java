package com.habeeb.isthara;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * Created by habeeb on 19/01/17.
 */

public class SpinnerAdapter extends BaseAdapter
{

    Context thisContext;
    ArrayList thisArrayList;

    int selectedPosition = -1;
    int textPixelValue = 15;

    public SpinnerAdapter(Context context, ArrayList arrayList)
    {
        super();

        this.thisContext = context;
        this.thisArrayList = arrayList;

        //textPixelValue = (int) (thisContext.getResources().getDimension(R.dimen.TextSize20sp) / thisContext.getResources().getDisplayMetrics().density);


    }

    @Override
    public int getCount()
    {
        int count = thisArrayList.size();

        //return count > 0 ? count-1 : count ;

        return count;
    }

    @Override
    public Object getItem(int position)
    {
        return thisArrayList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        TextView text = new TextView(thisContext);

        /*if (selectedPosition == -1)
        {
            text.setText("Select Doctor List");
        }
        else
        {

            text.setTextColor(Color.BLACK);
            text.setText(thisArrayList.get(position).toString());



        }*/

        text.setTextColor(Color.BLACK);
        text.setText(thisArrayList.get(position).toString());
        text.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        text.setTextSize(textPixelValue);

        return text;


    }

    @Override
    public boolean isEnabled(int position)
    {
        if(position == 0)
        {
            return false;
        }
        else
        {
            return true;
        }


        //return true;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent)
    {
        selectedPosition = position;



        if (position == 0)
        {
            TextView text = new TextView(thisContext);
            text.setTextColor(Color.WHITE);
            text.setText(thisArrayList.get(position).toString());
            text.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            text.setTextSize(textPixelValue);
            //text.setPaintFlags(text.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            text.setBackgroundColor(thisContext.getResources().getColor(R.color.colorGreylight));

            return text;
        }
        else
        {
            View v = convertView;
            LayoutInflater inflater = (LayoutInflater) thisContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.my_spinner, null);
            TextView textView = (TextView) v.findViewById(R.id.SpinnerTarget);
            textView.setText(thisArrayList.get(position).toString());
            textView.setTextSize(textPixelValue);
            v.setVisibility(View.VISIBLE);

            return v;
        }


    }


}
