package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadLocationsService;
import com.habeeb.isthara.MethodInfos.GetLocationsMethodInfo;
import com.habeeb.isthara.MethodInfos.PostReferralMethodInfo;
import com.habeeb.isthara.MethodInfos.ReferralsGetMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 08/09/17.
 */

public class UserSalesReferralActivity extends Activity implements MethodExecutor.TaskDelegate
{

    int serviceCount = 0;
    ToastClass toastClass = new ToastClass();

    String referralName = "";
    String referralContactNumber = "";
    String referralLocation = "";

    ArrayList locationsList = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_sales_refferal_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Sales Referral");

        getLocationsService();

    }


    /*
    * EVENT POST BUTTON ACTION
    * */
    public void postReferralButtonAction(View view)
    {
        EditText nameEditText = (EditText)findViewById(R.id.referralNameEditText);
        referralName = nameEditText.getText().toString().trim();

        EditText contactEditText = (EditText)findViewById(R.id.referralContactEditText);
        referralContactNumber = contactEditText.getText().toString().trim();

        if (referralName.length() == 0)
        {
            toastClass.ToastCalled(this,"Name Required");
            return;
        }
        else if (referralContactNumber.trim().length() == 0)
        {
            toastClass.ToastCalled(this,"Contact Number Required");
            return;
        }
        else if (referralLocation.length() == 0)
        {
            locationAlert();
            return;
        }
        else
        {
            postReferralDataService();
        }
    }

    /*
    * POST REFERRAL DATA SERIVCE
    * */
    private void postReferralDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        PostReferralMethodInfo postReferralMethodInfo = new PostReferralMethodInfo(ApplicationClass.userMobileNumber,referralName,referralContactNumber,referralLocation);
        methodExecutor.execute(postReferralMethodInfo);


    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            toastClass.ToastCalled(this,result);
            finish();
        }
        else if (serviceCount == 1)
        {
            readLocationService(result);
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }


    /*
    * GET LOCATIONS DATA SERIVCE
    * */
    private void getLocationsService()
    {

        serviceCount = 1;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        GetLocationsMethodInfo getLocationsMethodInfo = new GetLocationsMethodInfo();
        methodExecutor.execute(getLocationsMethodInfo);


    }

    /*
    * READ LOCATIONS SERVICE
    * */
    private void readLocationService(String response)
    {
        ReadLocationsService readLocationsService = new ReadLocationsService();
        readLocationsService.getLocationsData(response);

        locationsList.addAll(readLocationsService.locationsListArray);

        if (locationsList.size() > 0)
        {
            locationAlert();
        }
    }

    private void locationAlert()
    {
        final CharSequence[] choice = (CharSequence[]) locationsList.toArray(new CharSequence[locationsList.size()]);


        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setCancelable(false);
        alert.setTitle("LOCATION");
        alert.setSingleChoiceItems(choice, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                referralLocation = locationsList.get(which).toString();
            }
        });
        alert.setPositiveButton("DONE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                if (referralLocation.length() == 0) {
                    locationAlert();
                }
            }
        });
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                dialogInterface.dismiss();
            }
        });
        alert.show();
    }
}
