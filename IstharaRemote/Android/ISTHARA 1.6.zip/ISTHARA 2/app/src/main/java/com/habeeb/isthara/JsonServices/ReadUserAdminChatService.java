package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 20/12/17.
 */

public class ReadUserAdminChatService
{

    public ArrayList messagesListArray = new ArrayList();
    public ArrayList responseMessageList = new ArrayList();
    public ArrayList respondedByListArray = new ArrayList();
    public ArrayList datesList = new ArrayList();


    /*
    * USERS FEEDBACK
    * */
    public void getUsersChatData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String message = jsonObject.getString("usermessage");
                        String adminmessage = jsonObject.getString("adminmessage");
                        String username = jsonObject.getString("username");
                        String date = jsonObject.getString("chatdate");

                        //String[] separated = date.split(" ");

                        //date = separated[0];

                        message = message.trim();
                        adminmessage = adminmessage.trim();
                        username = username.trim();

                        messagesListArray.add(message);
                        responseMessageList.add(adminmessage);

                        if (adminmessage.length() != 0)
                        {
                            respondedByListArray.add("("+username+"/"+date+")");
                            datesList.add("");
                        }
                        else
                        {
                            respondedByListArray.add("");
                            datesList.add("("+date+")");
                        }

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }
}
