package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 14/09/17.
 */

public class FeedbackPostMethodInfo extends MethodInfo
{

    public FeedbackPostMethodInfo(String userID, String messageString)
    {
        params.put("userid",ApplicationClass.userLeaseID);
        params.put("message",messageString);
        params.put("insdate", ApplicationClass.getCurrentDateandTime());
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.feedbackService;
    }
}