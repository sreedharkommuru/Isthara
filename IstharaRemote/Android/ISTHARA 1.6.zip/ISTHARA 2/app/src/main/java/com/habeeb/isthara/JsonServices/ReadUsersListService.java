package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 29/10/17.
 */

public class ReadUsersListService
{
    public ArrayList userIDArray = new ArrayList();
    public ArrayList userNameArray = new ArrayList();
    public ArrayList roomNumbersList = new ArrayList();

    public void getUsersListData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String uid = jsonObject.getString("userid");
                        String username = jsonObject.getString("username");

                        username = username.trim();

                        if (username.length() != 0)
                        {
                            if (!userIDArray.contains(uid))
                            {
                                userIDArray.add(uid);
                                userNameArray.add(username);
                                roomNumbersList.add(jsonObject.getString("bednumber"));

                            }
                        }


                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }
}
