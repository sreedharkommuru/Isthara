package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by habeeb on 16/09/17.
 */

public class ReadOTPService
{

    public boolean success = false;
    public String name = "";

    public void readOTPData(String jsonData)
    {
        if (jsonData.length() != 0)
        {

            try {

                JSONObject jsonArray = new JSONObject(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {

                        success = jsonArray.getBoolean("success");

                        if (success)
                        {


                        }

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }
    }


}
