package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 17/09/17.
 */

public class FoodMenuGetMethodInfo extends MethodInfo
{

    public FoodMenuGetMethodInfo(String dateis,int checkUser)
    {
        params.put("date",dateis);

        if (checkUser == 1)
        {
            params.put("user","user");
        }


    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.foodMenuPostService;
    }
}
