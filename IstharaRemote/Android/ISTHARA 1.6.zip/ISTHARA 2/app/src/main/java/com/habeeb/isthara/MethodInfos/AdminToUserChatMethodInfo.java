package com.habeeb.isthara.MethodInfos;

import com.habeeb.isthara.ApplicationClass;

/**
 * Created by habeeb on 20/12/17.
 */

public class AdminToUserChatMethodInfo extends MethodInfo
{

    public AdminToUserChatMethodInfo(String userid)
    {
        params.put("userid", userid);
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.usersChatPostService;
    }
}
