package com.habeeb.isthara.MethodInfos;


/**
 * Created by habeeb on 16/09/17.
 */

public class OTPMethodInfo  extends MethodInfo
{

    public OTPMethodInfo(String number)
    {

        params.put("phoneNumber",number);
        params.put("type","sendOtp");
    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.baseApiURL;
    }
}
