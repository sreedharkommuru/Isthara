package com.habeeb.isthara.MethodInfos;

/**
 * Created by habeeb on 07/01/18.
 */

public class LocationInsertMethodInfo extends MethodInfo
{

    public LocationInsertMethodInfo(String locationName,String userid)
    {
        params.put("locationname",locationName);
        params.put("userid",userid);
        params.put("insert","insert");

    }

    @Override
    public String getRequestType()
    {
        return "POST";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.locationsPostService;
    }
}
