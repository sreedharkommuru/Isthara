package com.habeeb.isthara;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.text.TextUtils;

import com.habeeb.isthara.MethodInfos.MethodInfo;
import com.habeeb.isthara.MethodInfos.QueryString;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * Created by habeeb on 18/04/16.
 */
public class MethodExecutor extends AsyncTask<MethodInfo, Void, MethodResult>
{

    ConnectionDetector internetConnectionDetector;

    ToastClass toastClass = new ToastClass();

    Boolean isInternetPresent = true;


    private TaskDelegate delegate;

    HttpURLConnection conn;
    static final String COOKIES_HEADER = "Set-Cookie";


    String pushLink = "";

    String getRequestBody = "";

    String getRequestMethod = "";

    int serviceLogCount = 0;


    public interface TaskDelegate
    {
        //define you method headers to override

        void onTaskFisnishGettingData(String result);

       // void onTaskFailedGettingData(String link);


        void onTaskNoInternetConnection(String link, String reqestBodyData);

    }

    Context this_Context;
    private ProgressDialog progressBar;

    boolean errorOccured = false;

    public MethodExecutor(Context context)
    {

        this.this_Context = context;


        errorOccured = false;

        internetConnectionDetector = new ConnectionDetector(context);

        checkavailability();


    }

    public void setDelegate(Context delegate)
    {
        this.delegate = (TaskDelegate) delegate;
    }


    @Override public void onPreExecute()
    {

        if (isInternetPresent)
        {
            ProgressDialog progressDialog = new ProgressDialog((Activity) this_Context);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
            progressDialog.setCancelable(false);
            progressBar = progressDialog;
            progressBar.hide();
            progressBar.show();

        }

    }


    @Override
    protected MethodResult doInBackground(MethodInfo... mis)
    {

        MethodInfo mi = mis[0];

        String link = null;
        try
        {
            link = mi.getURL();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }


        String requestBody =  mi.getRequestBody();
        String requestType =  mi.getRequestType();
        serviceLogCount = mi.serviceLog();


        getRequestMethod = requestType;

        pushLink = link;


        getRequestBody = requestBody;

        MethodResult methodResult = new MethodResult();

        if (!isInternetPresent)
        {
            methodResult.exception = new QueryString.NetworkUnavailableException();

            return methodResult;
        }

        try
        {

            URL url = new URL(link);

            conn = (HttpURLConnection) url.openConnection();

            int timeheader = GetUnixTime();


            conn.setRequestMethod(requestType);



            if (requestType.equals("GET"))
            {




            }
            else
            {
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("charset", "utf-8");





                DataOutputStream wr = new DataOutputStream(conn.getOutputStream ());

                wr.writeBytes(requestBody);
                wr.flush();
                wr.close();
            }






            conn.setConnectTimeout(65000);
            conn.setReadTimeout(65000);

            conn.connect();

            methodResult.statusCode = conn.getResponseCode();


            BufferedReader streamReader = null;

            if (methodResult.statusCode != 200)
            {
                streamReader = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
            }
            else
            {
                streamReader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            }

            StringBuilder responseStrBuilder = new StringBuilder();

            String inputStr;
            while ((inputStr = streamReader.readLine()) != null)
                responseStrBuilder.append(inputStr);


            methodResult.responseBody = responseStrBuilder.toString();

            streamReader.close();


        }
        catch (IOException e)
        {

            errorOccured = true;

            methodResult.exception = e;


        }
        finally
        {
            if(conn != null)
                conn.disconnect();
        }


        return methodResult;

    }


    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected void onPostExecute(MethodResult methodResult)
    {



        if (methodResult.statusCode != 200 || methodResult.exception != null)
        {

            if (methodResult.statusCode == 401)
            {
                stopLoading();
                toastClass.ToastCalled(this_Context, "Your device was offline, please login again.");
                return;
            }





            if(methodResult.responseBody.equals("X-Client-Time"))
            {

                stopLoading();


                toastClass.ToastCalled(this_Context, "Your device's date time is not current.\nPlease set it to the present time.");

                return;

            }
            else if(methodResult.responseBody.equals("X-Client-Version"))
            {

                stopLoading();


                toastClass.ToastCalled(this_Context, "You are using an outdated version. Please upgrade to the latest version.");

                return;

            }

            if (serviceLogCount == 1)
            {
                stopLoading();
                delegate.onTaskNoInternetConnection("", "");
                return;
            }
            else if (serviceLogCount == 2)
            {
                stopLoading();
                toastClass.ToastCalled(this_Context,"Failed to access");
                return;
            }




            if (getRequestMethod.equals("POST"))
            {
                delegate.onTaskNoInternetConnection(pushLink, getRequestBody);
            }
            else if (!isInternetPresent && getRequestMethod.equals("POST"))
            {
                delegate.onTaskNoInternetConnection(pushLink, getRequestBody);
            }
            else if (!isInternetPresent)
            {
                delegate.onTaskNoInternetConnection("","");
            }




        }
        else
        {
            delegate.onTaskFisnishGettingData(methodResult.responseBody);

        }

        stopLoading();

    }







    public void stopLoading()
    {
        if (progressBar != null)
        {
            progressBar.dismiss();
            progressBar.hide();
            progressBar.cancel();
        }


    }



    public void checkavailability()
    {
        isInternetPresent = internetConnectionDetector.isConnectingToInternet();

        if (!isInternetPresent)
        {

            toastClass.ToastCalled(this_Context,"Internet Connection is not available");

        }

    }


    public int GetUnixTime()
    {
        Calendar calendar = Calendar.getInstance();
        long now = calendar.getTimeInMillis();
        int utc = (int)(now / 1000);
        return (utc);

    }

}


class MethodResult
{
    public int statusCode = 0;

    public String responseBody = "";

    public Exception exception = null;
}

