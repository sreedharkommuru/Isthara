package com.habeeb.isthara.JsonServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by habeeb on 10/09/17.
 */

public class ReadMaintenanceService
{
    public ArrayList idsListArray = new ArrayList();
    public ArrayList usersListArray = new ArrayList();
    public ArrayList messagesListArray = new ArrayList();
    public ArrayList respondedByListArray = new ArrayList();
    public ArrayList responseMessageList = new ArrayList();
    public ArrayList statusList = new ArrayList();
    public ArrayList roomNumberList = new ArrayList();
    public ArrayList datesList = new ArrayList();

    public ArrayList userIDListArray = new ArrayList();

    public void getMaintenanceStatusData(String jsonData)
    {
        statusList.add("View Status By");

        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        String status = jsonObject.getString("status");


                        if (!statusList.contains(status))
                        {
                            statusList.add(status);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }


    public void getMaintenanceData(String jsonData,String byStatus)
    {

        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        String id = jsonObject.getString("mid");
                        String userid = jsonObject.getString("userid");
                        String message = jsonObject.getString("message");
                        String respondedby = jsonObject.getString("username");
                        String response = jsonObject.getString("response");
                        String status = jsonObject.getString("status");


                        userid = userid.trim();
                        message = message.trim();

                        if (response.length() == 0)
                        {
                            respondedby = "";
                        }
                        else
                        {
                            respondedby = "("+respondedby+")";
                        }


                        if (status.equals(byStatus))
                        {

                            String bednumber = jsonObject.getString("bednumber");
                            String username = jsonObject.getString("username");


                            if (message.length() != 0 && !message.contains("null"))
                            {
                                idsListArray.add(id);
                                messagesListArray.add(message);
                                usersListArray.add(username + " - " + bednumber );
                                respondedByListArray.add(respondedby);
                                responseMessageList.add(response);

                            }
                        }
                        else if (byStatus.length() == 0)
                        {
                            if (message.length() != 0 && !message.contains("null"))
                            {
                                idsListArray.add(id);
                                messagesListArray.add(message);
                                usersListArray.add(userid);
                                respondedByListArray.add(respondedby);
                                responseMessageList.add(response);

                            }
                        }


                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }


    /*
    * ALL USERS LISTS
    * */
    public void getMaintenanceUsersData(String jsonData)
    {

        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        String id = jsonObject.getString("mid");
                        String userid = jsonObject.getString("userid");
                        String message = jsonObject.getString("message");
                        String respondedby = jsonObject.getString("username");
                        String response = jsonObject.getString("response");
                        String status = jsonObject.getString("status");
                        String date = jsonObject.getString("date");

                        String[] separated = date.split(" ");
                        date = separated[0];

                        userid = userid.trim();
                        message = message.trim();

                        String bednumber = jsonObject.getString("bednumber");
                        String username = jsonObject.getString("username");


                        if (!userIDListArray.contains(userid) && status.equalsIgnoreCase("pending"))
                        {
                            userIDListArray.add(userid);
                            idsListArray.add(id);
                            messagesListArray.add(message);
                            usersListArray.add(username);
                            respondedByListArray.add(respondedby);
                            responseMessageList.add(response);
                            roomNumberList.add(bednumber);
                            datesList.add(date);

                        }



                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }



    /*
    * USERS FEEDBACK
    * */
    public void getUsersMaintenanceData(String jsonData)
    {


        if (jsonData.length() != 0)
        {

            try {

                JSONArray jsonArray = new JSONArray(jsonData);

                if (jsonArray.length() != 0)
                {
                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        String message = jsonObject.getString("message");
                        String adminmessage = jsonObject.getString("response");
                        String username = jsonObject.getString("username");
                        String date = jsonObject.getString("date");

                        //String[] separated = date.split(" ");

                        //date = separated[0];

                        message = message.trim();
                        adminmessage = adminmessage.trim();
                        username = username.trim();

                        messagesListArray.add(message);
                        responseMessageList.add(adminmessage);

                        if (adminmessage.length() != 0)
                        {
                            respondedByListArray.add("("+username+"/"+date+")");
                            datesList.add("");
                        }
                        else
                        {
                            respondedByListArray.add("");
                            datesList.add("("+date+")");
                        }

                    }
                }
            }
            catch (Exception e)
            {
                System.out.print(e);
            }

        }

    }






}
