package com.habeeb.isthara.MethodInfos;



/**
 * Created by habeeb on 16/09/17.
 */

public class TokenUserMethodInfo extends MethodInfo
{

    public TokenUserMethodInfo(String number,String name)
    {

        params.put("number",number);
        params.put("name",name);

    }

    @Override
    public String getRequestType()
    {
        return "GET";
    }

    @Override
    public String getEndPoint()
    {
        return UrlFileClass.baseApiURL;
    }
}
