package com.habeeb.isthara;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.habeeb.isthara.JsonServices.ReadAdminService;
import com.habeeb.isthara.JsonServices.ReadOTPService;
import com.habeeb.isthara.JsonServices.ReadTokenService;
import com.habeeb.isthara.MethodInfos.AdminPostMethodInfo;
import com.habeeb.isthara.MethodInfos.OTPMethodInfo;
import com.habeeb.isthara.MethodInfos.TokenUserMethodInfo;

public class MainActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    EditText userMobileNumber,roomNumberEditText,bedNumberEditText;

    String userNumber = "";
    String roomNumber = "";
    String bedNumber = "";

    boolean doneEditing = false;

    /** Duration of wait **/
    private final int SPLASH_DISPLAY_LENGTH = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        openSplashScreenLayout();

        userMobileNumber = (EditText)findViewById(R.id.userMobileNumber);
        roomNumberEditText = (EditText)findViewById(R.id.roomNumberEditText);
        bedNumberEditText = (EditText)findViewById(R.id.bedNumberEditText);

        if (ApplicationClass.getLocalData(this,ApplicationClass.ROOMNUMBER).length() != 0)
        {
            findViewById(R.id.editMobileButton).setVisibility(View.VISIBLE);

            userMobileNumber.setText(ApplicationClass.getLocalData(this,ApplicationClass.mobileNumber));
            roomNumberEditText.setText(ApplicationClass.getLocalData(this,ApplicationClass.ROOMNUMBER));
            bedNumberEditText.setText(ApplicationClass.getLocalData(this,ApplicationClass.BEDNAME));
        }
        else
        {
            findViewById(R.id.editMobileButton).setVisibility(View.GONE);
        }

        if (ApplicationClass.getLocalData(this,ApplicationClass.ROOMNUMBER).length() == 0)
        {
            doneEditing = true;
        }
    }


    /*
    * SPLASH SCREEN LAYOUT
    * */
    private void openSplashScreenLayout()
    {
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {

                findViewById(R.id.splashScreenLayout).setVisibility(View.GONE);

            }
        }, SPLASH_DISPLAY_LENGTH);

    }

    /*
    * SIGN IN BUTTON ACTION
    * */
    public void signInAction(View view)
    {

        userNumber = userMobileNumber.getText().toString().trim();
        roomNumber = roomNumberEditText.getText().toString().trim();
        bedNumber = bedNumberEditText.getText().toString().trim();

        ApplicationClass.userMobileNumber = userNumber;

        ApplicationClass.deviceToken = ApplicationClass.getLocalData(this,"devicetoken");

        if (bedNumber.equalsIgnoreCase("admin"))
        {
            adminAuthenticationMethodInfo();//menuActivityAction();
        }
        else
        {
            if (userMobileNumber.getText().toString().trim().length() == 0)
            {
                toastClass.ToastCalled(this,"Required Mobile Number");
                return;
            }
            else if (roomNumberEditText.getText().toString().trim().length() == 0)
            {
                toastClass.ToastCalled(this,"Required Room Number");
                return;
            }
            else if (bedNumberEditText.getText().toString().trim().length() == 0)
            {
                toastClass.ToastCalled(this,"Required Bed Number");
                return;
            }
            else
            {
                if (userNumber.length() == 10)
                {
                    getUserServiceMethodInfo();
                }
                else
                {
                    toastClass.ToastCalled(this,"Required Correct number");
                    return;
                }

            }
        }




    }

    /*
    * REGISTRATION BUTTON ACTION
    * */
    public void registrationAction(View view)
    {
        Intent intent = new Intent(this,RegistrationActivity.class);
        startActivity(intent);
    }

    /*
    * GET USER METHOD INFO
    * */
    private void getUserServiceMethodInfo()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        TokenUserMethodInfo tokenUserMethodInfo = new TokenUserMethodInfo(userNumber,roomNumber);
        methodExecutor.execute(tokenUserMethodInfo);

    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readResponseData(result);
        }
        else if (serviceCount == 1)
        {
            readOTPResponseData(result);
        }
        else if (serviceCount == 2)
        {
            readAdminResponse(result);
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }


    /*
    * READ RESPONSE DATA
    * */
    private void readResponseData(String response)
    {


        ApplicationClass.emptyAllObjects();

        if (!bedNumber.contains(roomNumber))
        {
            bedNumber = roomNumber+"-"+bedNumber;
        }

        ReadTokenService readTokenService = new ReadTokenService();
        readTokenService.readTokenData(response,roomNumber,bedNumber);

        if (readTokenService.success)
        {
            if (ApplicationClass.userRoomNumber.length() != 0)
            {

                ApplicationClass.userMobileNumber = userNumber;

                if (doneEditing)
                {
                    alertResponseDialog();
                }
                else
                {
                    menuActivityAction();
                }

            }
            else
            {
                usersFields();
                toastClass.ToastCalled(this,"User not match");
                return;
            }
        }
        else
        {
            sendOTPServiceMethodInfo();
        }

    }

    /*
    * MENU ACTIVITY ACTION
    * */
    private void menuActivityAction()
    {
        Intent intent = new Intent(this,MenuActivity.class);
        startActivity(intent);
    }


    /*
    * GET USER METHOD INFO
    * */
    private void sendOTPServiceMethodInfo()
    {

        serviceCount = 1;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        OTPMethodInfo otpMethodInfo = new OTPMethodInfo(userNumber);
        methodExecutor.execute(otpMethodInfo);

    }


    /*
    * OTP ACTIVITY SCREEN
    * */
    private void otpVerifyAction()
    {
        Intent intent = new Intent(this,OTPActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume()
    {


        EditText userMobileNumber = (EditText)findViewById(R.id.userMobileNumber);
        EditText roomNumberEditText = (EditText)findViewById(R.id.roomNumberEditText);
        EditText bedNumberEditText = (EditText)findViewById(R.id.bedNumberEditText);

        userMobileNumber.setText("");
        roomNumberEditText.setText("");
        bedNumberEditText.setText("");

        if (ApplicationClass.getLocalData(this,ApplicationClass.ROOMNUMBER).length() != 0)
        {
            findViewById(R.id.editMobileButton).setVisibility(View.VISIBLE);
            userMobileNumber.setEnabled(false);
            roomNumberEditText.setEnabled(false);
            bedNumberEditText.setEnabled(false);

            userMobileNumber.setText(ApplicationClass.getLocalData(this,ApplicationClass.mobileNumber));
            roomNumberEditText.setText(ApplicationClass.getLocalData(this,ApplicationClass.ROOMNUMBER));
            bedNumberEditText.setText(ApplicationClass.getLocalData(this,ApplicationClass.BEDNAME));
        }
        else
        {
            findViewById(R.id.editMobileButton).setVisibility(View.GONE);
        }

        super.onResume();

    }


    /*
    * READ RESPONSE DATA
    * */
    private void readOTPResponseData(String response)
    {
        ReadOTPService readOTPService = new ReadOTPService();
        readOTPService.readOTPData(response);

        if (readOTPService.success)
        {
            otpVerifyAction();
        }
        else
        {
            toastClass.ToastCalled(this,"No user found with this number");
            return;
        }

    }

    /*
    * GET ADMIN METHOD INFO
    * */
    private void adminAuthenticationMethodInfo()
    {

        serviceCount = 2;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        AdminPostMethodInfo adminPostMethodInfo = new AdminPostMethodInfo(roomNumber,userNumber);
        methodExecutor.execute(adminPostMethodInfo);

    }

    /*
    * READ ADMING DATA
    * */
    private void readAdminResponse(String response)
    {
        ReadAdminService readAdminService = new ReadAdminService();
        readAdminService.getAdminData(response);

        if (roomNumber.equals(readAdminService.admuserid) && userNumber.equals(userNumber))
        {

            ApplicationClass.userMobileNumber = userNumber;
            ApplicationClass.userRoomNumber = roomNumber;
            ApplicationClass.userLoginRole = "admin";
            ApplicationClass.userLoginName = readAdminService.admusername;

            if (doneEditing)
            {
                alertResponseDialog();
            }
            else
            {
                menuActivityAction();
            }

        }
        else
        {
            usersFields();
            toastClass.ToastCalled(this,"Required Valid Details");
        }
    }

    /*
    * EDIT BUTTON ACTION
    * */
    public void editButtonAction(View view)
    {

        doneEditing = true;

        usersFields();

        findViewById(R.id.editMobileButton).setVisibility(View.GONE);
    }

    /*
    * USERS FILEDS
    * */
    private void usersFields()
    {
        EditText userMobileNumber = (EditText)findViewById(R.id.userMobileNumber);
        EditText roomNumberEditText = (EditText)findViewById(R.id.roomNumberEditText);
        EditText bedNumberEditText = (EditText)findViewById(R.id.bedNumberEditText);

        userMobileNumber.setText("");
        roomNumberEditText.setText("");
        bedNumberEditText.setText("");

        userMobileNumber.setEnabled(true);
        roomNumberEditText.setEnabled(true);
        bedNumberEditText.setEnabled(true);
    }


    /*
    * ALERT DIALOG FOR RESPONSE
    * */
    private void alertResponseDialog()
    {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setCancelable(false);

        TextView text = new TextView(this);
        text.setTextColor(Color.WHITE);
        text.setText("SAVE DETAILS");
        text.setBackgroundColor(this.getResources().getColor(R.color.colorGrey));
        text.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        alertDialog.setCustomTitle(text);

        alertDialog.setMessage("Would you like to save details for future logins?");

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        saveLoginDetails();
                    }
                });

        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        menuActivityAction();
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }

    /*
    * SAVE USER DETAILS
    * */
    private void saveLoginDetails()
    {

        doneEditing = false;

        ApplicationClass.storeLocalData(this,ApplicationClass.mobileNumber,userNumber);
        ApplicationClass.storeLocalData(this,ApplicationClass.ROOMNUMBER,roomNumber);
        ApplicationClass.storeLocalData(this,ApplicationClass.BEDNAME,bedNumber);

        menuActivityAction();
    }

}
