package com.habeeb.isthara;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;


import com.habeeb.isthara.JsonServices.ReadMaintenanceService;
import com.habeeb.isthara.MethodInfos.MaintenanceResponseMethodInfo;
import com.habeeb.isthara.MethodInfos.UsersMaintenanceListMethodInfo;

import java.util.ArrayList;

/**
 * Created by habeeb on 29/10/17.
 */

public class MaintenanceAdminResponseActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    String userID = "";
    String userName = "";

    ListAdapter adapter;
    ListView listView;

    ArrayList userMessageList = new ArrayList();
    ArrayList adminMessageList = new ArrayList();
    ArrayList adminNameList = new ArrayList();
    ArrayList datesList = new ArrayList();

    String enteredMessage = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_list_maintenance_layout);

        userID = getIntent().getStringExtra("userID");
        userName = getIntent().getStringExtra("userName");

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText(userName);
        findViewById(R.id.rightButton).setVisibility(View.GONE);

        findViewById(R.id.moreButton).setVisibility(View.GONE);

        getMaintenanceDataService();

    }


    /*
    * POST FEEDBACK DATA SERIVCE
    * */
    private void getMaintenanceDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        UsersMaintenanceListMethodInfo usersFeedbackListMethodInfo = new UsersMaintenanceListMethodInfo(userID);
        methodExecutor.execute(usersFeedbackListMethodInfo);

    }

    /*
    * LOAD USERS IN LIST
    * */
    private void loadUsersList()
    {

        listView = (ListView)findViewById(R.id.listView);

        listView.setAdapter(null);

        adapter= new ListAdapter(userMessageList,adminMessageList,adminNameList,2);
        adapter.list4rdArray = new ArrayList();
        adapter.list4rdArray.addAll(datesList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected =  adapter.getItem(position);

            }
        });

        listView.setSelection(listView.getAdapter().getCount()-1);
        this.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            readJsonData(result);
        }
        else if (serviceCount == 1)
        {
            getMaintenanceDataService();
        }
        else
        {
            toastClass.ToastCalled(this,result);
            finish();
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData)
    {

    }

    /*
    * GET FEEDBACK JSON DATA
    * */
    private void readJsonData(String response)
    {

        userMessageList.clear();
        adminMessageList.clear();
        adminNameList.clear();
        datesList.clear();

        ReadMaintenanceService readMaintenanceService = new ReadMaintenanceService();
        readMaintenanceService.getUsersMaintenanceData(response);

        userMessageList.addAll(readMaintenanceService.messagesListArray);
        adminMessageList.addAll(readMaintenanceService.responseMessageList);
        adminNameList.addAll(readMaintenanceService.respondedByListArray);
        datesList.addAll(readMaintenanceService.datesList);

        if (userMessageList.size() != 0)
        {
            loadUsersList();
        }

    }




    @Override
    protected void onResume()
    {
        super.onResume();
    }

    /*
    * SEND MESSAGE EDIT TEXT VIEW
    * */
    public void getMessageSendAction(View view)
    {
        EditText userMessageEditText = (EditText)findViewById(R.id.userMessageEditText);
        enteredMessage = userMessageEditText.getText().toString().trim();

        if (enteredMessage.length() != 0)
        {
            postMaintenanceResponseDataService();
        }
        else
        {
            toastClass.ToastCalled(this,"Required Message");
            userMessageEditText.requestFocus();
        }

    }

    /*
    * POST USER MESSAGE
    * */
    public void postMaintenanceResponseDataService()
    {

        serviceCount = 1;

        EditText userMessageEditText = (EditText)findViewById(R.id.userMessageEditText);
        userMessageEditText.setText("");

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);


        MaintenanceResponseMethodInfo maintenanceResponseMethodInfo = new MaintenanceResponseMethodInfo(userID,enteredMessage);
        methodExecutor.execute(maintenanceResponseMethodInfo);

    }
}
