package com.habeeb.isthara;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.habeeb.isthara.MethodInfos.EventPostMethodInfo;

import java.util.Calendar;

/**
 * Created by habeeb on 08/09/17.
 */

public class ManageEventsActivity extends Activity implements MethodExecutor.TaskDelegate
{

    ToastClass toastClass = new ToastClass();

    int serviceCount = 0;

    private Calendar calendar;
    private int year, month, day;

    Button eventDateButton;
    String eventDateString = "0";
    String eventMessage = "";


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_events_layout);

        TextView topTitleTextView = (TextView)findViewById(R.id.topTitleTextView);
        topTitleTextView.setText("Manage Events");


        eventDateButton = (Button)findViewById(R.id.eventDateButton);


    }


    /*
    * DATE BUTTON ACTION
    * */

    public void dateButtonAction(View v)
    {
        setDate(v);
    }

    /*
    * DATE PICKER DISPLAY
    * */

    public void setDate(View view)
    {
        showDialog(999);
    }

    @Override
    protected Dialog onCreateDialog(int id)
    {
        if (id == 999)
        {

            DatePickerDialog picker = new DatePickerDialog(this, myDateListener, year, month, day);

            try {

                picker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

            }
            catch (Exception e)
            {

                e.printStackTrace();
            }



            return picker;
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {

            showDate(arg1, arg2+1, arg3);
        }
    };

    private void showDate(int year, int month, int day)
    {


        String monthString = "" + month;
        String dayString = "" + day;

        if (month < 10)
        {
            monthString = "0" + month;
        }

        if (day < 10)
        {
            dayString = "0" + day;
        }


        eventDateButton.setText(year+"-"+monthString+"-"+dayString);
        eventDateString = year+"-"+monthString+"-"+dayString;


    }


    /*
    * EVENT POST BUTTON ACTION
    * */
    public void postEventButtonAction(View view)
    {
        EditText eventMessageEditText = (EditText)findViewById(R.id.eventMessageEditText);
        eventMessage = eventMessageEditText.getText().toString().trim();

        if (eventMessage.length() == 0)
        {
            toastClass.ToastCalled(this,"Event Message Required");
            return;
        }
        else if (eventDateString.trim().length() == 0)
        {
            toastClass.ToastCalled(this,"Event Date Required");
            return;
        }
        else
        {
            postEventDataService();
        }
    }

    /*
    * POST EVENT DATA SERIVCE
    * */
    private void postEventDataService()
    {

        serviceCount = 0;

        MethodExecutor methodExecutor = new MethodExecutor(this);
        methodExecutor.setDelegate(this);

        EventPostMethodInfo eventPostMethodInfo = new EventPostMethodInfo(ApplicationClass.userLoginName,eventMessage,eventDateString);
        methodExecutor.execute(eventPostMethodInfo);


    }

    @Override
    public void onTaskFisnishGettingData(String result)
    {
        if (serviceCount == 0)
        {
            toastClass.ToastCalled(this,result);
            finish();
        }

    }

    @Override
    public void onTaskNoInternetConnection(String link, String reqestBodyData) {

    }
}
