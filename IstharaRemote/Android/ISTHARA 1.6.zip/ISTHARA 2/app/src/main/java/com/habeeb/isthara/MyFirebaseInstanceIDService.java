package com.habeeb.isthara;

import android.content.Intent;
import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;


/**
 * Created by habeeb on 30/09/17.
 */

public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService
{

    public static final String TOKEN_BROADCAST = "myfcmtokenboardcast";

    @Override
    public void onTokenRefresh() {
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d("MyFireBaseID", "Refreshed token: " + refreshedToken);


        getApplicationContext().sendBroadcast(new Intent(TOKEN_BROADCAST));
        storeToken(refreshedToken);
    }


    private void storeToken(String token)
    {
        ApplicationClass.storeLocalData(getApplicationContext(),"devicetoken",token);

    }


}
