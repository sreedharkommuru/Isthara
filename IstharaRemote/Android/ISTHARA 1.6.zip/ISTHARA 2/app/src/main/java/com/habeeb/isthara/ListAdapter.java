package com.habeeb.isthara;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;

import com.habeeb.isthara.databinding.RowItemBinding;
import com.habeeb.isthara.databinding.Row2ItemBinding;
import com.habeeb.isthara.databinding.Row3ItemBinding;
import com.habeeb.isthara.databinding.Row5ItemBinding;


import java.util.ArrayList;
import java.util.List;

import static java.security.AccessController.getContext;

/**
 * Created by anupamchugh on 07/02/16.
 */
public class ListAdapter extends BaseAdapter implements Filterable {

    List<String> mData;
    List<String> mStringFilterList;
    List<String> list3rdArray;
    ArrayList list4rdArray;

    List<String> colorCodes;

    ValueFilter valueFilter;
    private LayoutInflater inflater;

    private int viewsCount = 1;

    List<String> fontData;

    public ListAdapter(List<String> cancel_type,List<String> fontList,List<String> list3Array, int numberofviews) {
        mData=cancel_type;
        mStringFilterList = cancel_type;
        fontData = fontList;

        list3rdArray = list3Array;

        viewsCount = numberofviews;
    }


    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public String getItem(int position)
    {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {

        if (inflater == null) {
            inflater = (LayoutInflater) parent.getContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }


        if (viewsCount == 0)
        {
            RowItemBinding rowItemBinding = DataBindingUtil.inflate(inflater, R.layout.row_item, parent, false);
            rowItemBinding.stringName.setText(mData.get(position));

            if (fontData.size() != 0)
            {
                rowItemBinding.fontIcon.setText(Html.fromHtml(fontData.get(position)).toString());

                if (colorCodes != null)
                {
                    if (colorCodes.size() >= position)
                    {
                        rowItemBinding.fontIcon.setTextColor(Color.parseColor(colorCodes.get(position)));
                        //rowItemBinding.customdivider.setBackgroundColor(Color.parseColor(colorCodes.get(position)));
                    }
                }

            }
            else
            {
                rowItemBinding.fontIcon.setVisibility(View.GONE);
            }

            //Animation animation = AnimationUtils.loadAnimation(parent.getContext(), R.anim.slidein);
            //rowItemBinding.stringName.setAnimation(animation);


            return rowItemBinding.getRoot();

        }
        else if (viewsCount == 2)
        {
            Row2ItemBinding rowItemBinding = DataBindingUtil.inflate(inflater, R.layout.row_2_item, parent, false);
            rowItemBinding.stringName.setText(mData.get(position));
            //rowItemBinding.stringName.setTextColor(Color.BLUE);

            if (mData.get(position).toString().length() == 0)
            {
                rowItemBinding.stringName.setVisibility(View.GONE);
            }

            if (fontData.size() != 0)
            {
                rowItemBinding.messageString.setText(fontData.get(position));

                if (fontData.get(position).toString().length() == 0)
                {
                    rowItemBinding.messageString.setVisibility(View.GONE);
                }
            }
            else
            {
                rowItemBinding.messageString.setVisibility(View.GONE);
            }

            if (list3rdArray.size() != 0)
            {
                rowItemBinding.respondedByString.setText(list3rdArray.get(position));
            }
            else
            {
                rowItemBinding.respondedByString.setVisibility(View.GONE);
            }

            if (list4rdArray != null)
            {
                if (list4rdArray.size() != 0)
                {
                    rowItemBinding.requestDateString.setText(list4rdArray.get(position).toString());
                }
                else
                {
                    rowItemBinding.requestDateString.setVisibility(View.GONE);
                }
            }




            return rowItemBinding.getRoot();

        }
        else if (viewsCount == 3)
        {
            Row3ItemBinding rowItemBinding = DataBindingUtil.inflate(inflater, R.layout.row_3_item, parent, false);
            rowItemBinding.stringName.setText(mData.get(position));


            if (fontData.size() != 0)
            {
                rowItemBinding.messageString.setText(fontData.get(position));
                rowItemBinding.messageString.setTextColor(Color.BLACK);
            }
            else
            {
                rowItemBinding.messageString.setVisibility(View.GONE);
            }

            if (list3rdArray.size() != 0)
            {
                if (list3rdArray.get(position).toString().equalsIgnoreCase("1"))
                {
                    rowItemBinding.fontIcon.setText(R.string.icon_checkmark);
                    rowItemBinding.fontIcon.setTextColor(Color.GREEN);
                    rowItemBinding.stringName.setTextColor(parent.getContext().getResources().getColor(R.color.colorAccent));
                }
                else
                {
                    //rowItemBinding.stringName.setTextColor(Color.BLUE);
                    rowItemBinding.fontIcon.setVisibility(View.GONE);
                }

            }
            else
            {
                rowItemBinding.fontIcon.setVisibility(View.GONE);
            }

            //Animation animation = AnimationUtils.loadAnimation(parent.getContext(), R.anim.slidein);
            //rowItemBinding.stringName.setAnimation(animation);


            return rowItemBinding.getRoot();

        }
        else if (viewsCount == 4)
        {
            Row5ItemBinding rowItemBinding = DataBindingUtil.inflate(inflater, R.layout.row_5_item, parent, false);
            rowItemBinding.stringName.setText(mData.get(position));
            rowItemBinding.stringName.setTextColor(Color.BLUE);

            if (mData.get(position).toString().length() == 0)
            {
                rowItemBinding.stringName.setVisibility(View.GONE);
            }

            if (fontData.size() != 0)
            {
                rowItemBinding.messageString.setText(fontData.get(position));
            }
            else
            {
                rowItemBinding.messageString.setVisibility(View.GONE);
            }

            if (list3rdArray.size() != 0)
            {
                rowItemBinding.respondedByString.setText(list3rdArray.get(position));
            }
            else
            {
                rowItemBinding.respondedByString.setVisibility(View.GONE);
            }

            //Animation animation = AnimationUtils.loadAnimation(parent.getContext(), R.anim.slidein);
            //rowItemBinding.stringName.setAnimation(animation);


            return rowItemBinding.getRoot();

        }

        else
        {
            Row2ItemBinding rowItemBinding = DataBindingUtil.inflate(inflater, R.layout.row_2_item, parent, false);
            rowItemBinding.stringName.setText(mData.get(position));
            rowItemBinding.stringName.setPaintFlags(rowItemBinding.stringName.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);


            if (fontData.size() != 0)
            {
                rowItemBinding.messageString.setText(fontData.get(position));
            }
            else
            {
                rowItemBinding.messageString.setVisibility(View.GONE);
            }

            if (list3rdArray.size() != 0)
            {
                rowItemBinding.respondedByString.setText(list3rdArray.get(position));
            }
            else
            {
                rowItemBinding.respondedByString.setVisibility(View.GONE);
            }

            //Animation animation = AnimationUtils.loadAnimation(parent.getContext(), R.anim.slidein);
            //rowItemBinding.stringName.setAnimation(animation);


            return rowItemBinding.getRoot();

        }


    }

    @Override
    public Filter getFilter() {
        if (valueFilter == null) {
            valueFilter = new ValueFilter();
        }
        return valueFilter;
    }

    private class ValueFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint != null && constraint.length() > 0) {
                List<String> filterList = new ArrayList<>();
                for (int i = 0; i < mStringFilterList.size(); i++) {
                    if ((mStringFilterList.get(i).toUpperCase()).contains(constraint.toString().toUpperCase())) {
                        filterList.add(mStringFilterList.get(i));
                    }
                }
                results.count = filterList.size();
                results.values = filterList;
            } else {
                results.count = mStringFilterList.size();
                results.values = mStringFilterList;
            }
            return results;

        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mData = (List<String>) results.values;
            notifyDataSetChanged();
        }

    }

}
